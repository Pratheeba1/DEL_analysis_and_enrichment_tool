library(tidyverse)
library(arrow)
library(plotly)
library(htmlwidgets)

theme_set(theme_light(base_size = 14))

# -----------------------------
# Input / output
# -----------------------------
input_molecule_parquet <- "/home/prp50ch/DEL_analysis_5/results/molecule_scores_all.parquet"

selected_pseudocount <- 1

# Use empty-beads-only enrichment for plotting
selected_score <- "target_vs_empty_beads"

outdir <- paste0(
  "/home/prp50ch/DEL_analysis_5/results/DEL_enrichment_plots_p",
  gsub("\\.", "p", selected_pseudocount),
  "_",
  selected_score
)

dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

# -----------------------------
# User thresholds
# -----------------------------
min_signal <- 10
score_cutoff <- 0.5

# For 3D scatter
scatter_score_cutoff <- 3
max_3d_points_per_target <- 50000

# -----------------------------
# Helpers
# -----------------------------
fix_num <- function(x) {
  if (is.list(x)) as.numeric(unlist(x)) else as.numeric(x)
}

safe_filename <- function(x) {
  x |>
    str_replace_all("[^A-Za-z0-9_\\-]", "_")
}

# -----------------------------
# Run info
# -----------------------------
run_info_file <- file.path(outdir, "run_info.txt")

cat(
  "DEL enrichment plotting run\n",
  "Started: ", as.character(Sys.time()), "\n",
  "Input parquet: ", input_molecule_parquet, "\n",
  "Output directory: ", outdir, "\n",
  "Selected pseudocount: ", selected_pseudocount, "\n",
  "Selected score: ", selected_score, "\n",
  "min_signal: ", min_signal, "\n",
  "score_cutoff: ", score_cutoff, "\n",
  "scatter_score_cutoff: ", scatter_score_cutoff, "\n",
  file = run_info_file,
  sep = ""
)

message("Output directory: ", outdir)

# -----------------------------
# Read only selected pseudocount from parquet
# -----------------------------
message("Reading molecule scores parquet...")

df <- arrow::open_dataset(input_molecule_parquet) |>
  filter(pseudocount == selected_pseudocount) |>
  collect() |>
  as_tibble()

message("Rows loaded: ", nrow(df))

if (nrow(df) == 0) {
  stop("No rows found for pseudocount = ", selected_pseudocount)
}

df <- df |>
  mutate(
    pseudocount = fix_num(pseudocount),
    target_mean_per_mil = fix_num(target_mean_per_mil),
    native_mean_per_mil = fix_num(native_mean_per_mil),
    target_vs_native = fix_num(target_vs_native),
    corrected_score = fix_num(corrected_score),
    target_vs_mean_control = fix_num(target_vs_mean_control),
    target_vs_empty_beads = fix_num(target_vs_empty_beads)
  )

if (!selected_score %in% names(df)) {
  stop(
    "Selected score column not found: ", selected_score,
    "\nAvailable columns are:\n",
    paste(names(df), collapse = ", ")
  )
}

df <- df |>
  mutate(selected_score_value = fix_num(.data[[selected_score]]))

targets <- sort(unique(df$target))

cat(
  "Rows loaded: ", nrow(df), "\n",
  "Targets: ", paste(targets, collapse = ", "), "\n",
  file = run_info_file,
  append = TRUE,
  sep = ""
)

# -----------------------------
# Define hits for BB bar plots
# -----------------------------
hits <- df |>
  filter(
    !is.na(selected_score_value),
    !is.na(target_mean_per_mil),
    target_mean_per_mil > min_signal,
    selected_score_value > score_cutoff
  )

message("Hits for BB bar plots: ", nrow(hits))

cat(
  "Hits for BB bar plots: ", nrow(hits), "\n",
  file = run_info_file,
  append = TRUE,
  sep = ""
)

if (nrow(hits) == 0) {
  stop("No hits found for current thresholds. Lower score_cutoff or min_signal.")
}

# -----------------------------
# Save hit table
# -----------------------------
write_csv(
  hits,
  file.path(outdir, "filtered_hits_used_for_BB_barplots.csv")
)

# -----------------------------
# 1) Violin plot: selected score
# -----------------------------
message("Making violin plot: selected score...")

p_violin_selected <- ggplot(df, aes(x = target, y = selected_score_value, fill = target)) +
  geom_violin(trim = TRUE) +
  geom_hline(yintercept = score_cutoff, linetype = "dashed", color = "red") +
  labs(
    title = paste0(selected_score, " enrichment by target protein"),
    subtitle = paste0("Pseudocount = ", selected_pseudocount),
    x = "Target protein",
    y = selected_score
  ) +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )

ggsave(
  filename = file.path(outdir, paste0("violin_", selected_score, ".png")),
  plot = p_violin_selected,
  width = 10,
  height = 7,
  dpi = 300
)

# -----------------------------
# 2) Violin plot: corrected_score for comparison
# -----------------------------
message("Making violin plot: corrected_score...")

p_violin_corrected <- ggplot(df, aes(x = target, y = corrected_score, fill = target)) +
  geom_violin(trim = TRUE) +
  geom_hline(yintercept = score_cutoff, linetype = "dashed", color = "red") +
  labs(
    title = "Corrected score enrichment by target protein",
    subtitle = paste0("Pseudocount = ", selected_pseudocount),
    x = "Target protein",
    y = "corrected_score"
  ) +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )

ggsave(
  filename = file.path(outdir, "violin_corrected_score_for_comparison.png"),
  plot = p_violin_corrected,
  width = 10,
  height = 7,
  dpi = 300
)

# -----------------------------
# 3) Main BB contribution bar plot
# -----------------------------
message("Making main BB contribution bar plot...")

bar_df <- hits |>
  select(target, BB1_name, BB2_name, BB3_name) |>
  pivot_longer(
    cols = c(BB1_name, BB2_name, BB3_name),
    names_to = "BB_region",
    values_to = "BB_name"
  ) |>
  mutate(
    BB_region = recode(
      BB_region,
      BB1_name = "BB1",
      BB2_name = "BB2",
      BB3_name = "BB3"
    ),
    BB_region = factor(BB_region, levels = c("BB1", "BB2", "BB3"))
  ) |>
  count(target, BB_region, BB_name, name = "n")

write_csv(
  bar_df,
  file.path(outdir, "BB_barplot_counts.csv")
)

p_bar <- ggplot(bar_df, aes(x = BB_name, y = n, fill = target)) +
  geom_col() +
  facet_grid(target ~ BB_region, scales = "free_x", space = "free_x") +
  labs(
    title = "Number of enriched complexes with each component",
    subtitle = paste0(
      selected_score,
      " > ", score_cutoff,
      "; target CPM > ", min_signal,
      "; pseudocount = ", selected_pseudocount
    ),
    x = "Building blocks",
    y = "Number of enriched DNA barcodes versus target protein"
  ) +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, size = 5),
    strip.text = element_text(face = "bold"),
    legend.position = "right"
  )

ggsave(
  filename = file.path(outdir, "barplot_enriched_complexes_by_BB.png"),
  plot = p_bar,
  width = 20,
  height = 12,
  dpi = 300
)

# -----------------------------
# 4) Per-target BB bar plots
# -----------------------------
message("Making per-target BB bar plots...")

for (tg in targets) {
  
  tg_hits <- hits |>
    filter(target == tg)
  
  if (nrow(tg_hits) == 0) next
  
  tg_bar <- tg_hits |>
    select(BB1_name, BB2_name, BB3_name) |>
    pivot_longer(
      cols = c(BB1_name, BB2_name, BB3_name),
      names_to = "BB_region",
      values_to = "BB_name"
    ) |>
    mutate(
      BB_region = recode(
        BB_region,
        BB1_name = "BB1",
        BB2_name = "BB2",
        BB3_name = "BB3"
      ),
      BB_region = factor(BB_region, levels = c("BB1", "BB2", "BB3"))
    ) |>
    count(BB_region, BB_name, name = "n")
  
  p_tg_bar <- ggplot(tg_bar, aes(x = BB_name, y = n)) +
    geom_col(fill = "grey45") +
    facet_grid(. ~ BB_region, scales = "free_x", space = "free_x") +
    labs(
      title = paste0(tg, ": enriched BBs"),
      subtitle = paste0(
        selected_score,
        " > ", score_cutoff,
        "; target CPM > ", min_signal
      ),
      x = "Building blocks",
      y = "Count"
    ) +
    theme(
      plot.title = element_text(face = "bold"),
      axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, size = 6),
      strip.text = element_text(face = "bold"),
      legend.position = "none"
    )
  
  ggsave(
    filename = file.path(outdir, paste0(safe_filename(tg), "_BB_barplot.png")),
    plot = p_tg_bar,
    width = 16,
    height = 6,
    dpi = 300
  )
}

# -----------------------------
# 5) Interactive 3D scatter plots
# -----------------------------
message("Preparing 3D scatter data...")

scatter_df <- df |>
  filter(
    !is.na(selected_score_value),
    !is.na(target_mean_per_mil),
    target_mean_per_mil > min_signal,
    selected_score_value > scatter_score_cutoff
  )

message("Points for 3D scatter: ", nrow(scatter_df))

write_csv(
  scatter_df,
  file.path(outdir, "filtered_hits_used_for_3D_scatter.csv")
)

cat(
  "Points for 3D scatter: ", nrow(scatter_df), "\n",
  file = run_info_file,
  append = TRUE,
  sep = ""
)

for (tg in targets) {
  
  tg_scatter <- scatter_df |>
    filter(target == tg)
  
  if (nrow(tg_scatter) == 0) next
  
  if (nrow(tg_scatter) > max_3d_points_per_target) {
    message("Target ", tg, " has > ", max_3d_points_per_target, " points; keeping top points by score.")
    tg_scatter <- tg_scatter |>
      arrange(desc(selected_score_value)) |>
      slice_head(n = max_3d_points_per_target)
  }
  
  bb1_levels <- sort(unique(tg_scatter$BB1_name))
  bb2_levels <- sort(unique(tg_scatter$BB2_name))
  bb3_levels <- sort(unique(tg_scatter$BB3_name))
  
  tg_scatter <- tg_scatter |>
    mutate(
      BB1_index = as.integer(factor(BB1_name, levels = bb1_levels)),
      BB2_index = as.integer(factor(BB2_name, levels = bb2_levels)),
      BB3_index = as.integer(factor(BB3_name, levels = bb3_levels)),
      hover_text = paste0(
        "Target: ", target,
        "<br>BB1: ", BB1_name,
        "<br>BB1 SMILES: ", BB1_smiles,
        "<br>BB2: ", BB2_name,
        "<br>BB2 SMILES: ", BB2_smiles,
        "<br>BB3: ", BB3_name,
        "<br>BB3 SMILES: ", BB3_smiles,
        "<br>target CPM: ", round(target_mean_per_mil, 3),
        "<br>native CPM: ", round(native_mean_per_mil, 3),
        "<br>target_vs_native: ", round(target_vs_native, 3),
        "<br>target_vs_empty_beads: ", round(target_vs_empty_beads, 3),
        "<br>target_vs_mean_control: ", round(target_vs_mean_control, 3),
        "<br>corrected_score: ", round(corrected_score, 3),
        "<br>Selected score (", selected_score, "): ", round(selected_score_value, 3),
        "<br>limiting_control: ", limiting_control,
        "<br>pseudocount: ", pseudocount
      )
    )
  
  p3d <- plot_ly(
    data = tg_scatter,
    x = ~BB1_index,
    y = ~BB2_index,
    z = ~BB3_index,
    type = "scatter3d",
    mode = "markers",
    text = ~hover_text,
    hoverinfo = "text",
    marker = list(
      size = 5,
      color = ~selected_score_value,
      colorscale = "Viridis",
      showscale = TRUE,
      opacity = 0.85,
      colorbar = list(title = selected_score)
    )
  ) |>
    layout(
      title = paste0(
        tg,
        ": 3D BB1-BB2-BB3 hit space<br>",
        "<sup>",
        selected_score,
        " > ", scatter_score_cutoff,
        "; target CPM > ", min_signal,
        "; pseudocount = ", selected_pseudocount,
        "</sup>"
      ),
      scene = list(
        xaxis = list(title = "BB1 index"),
        yaxis = list(title = "BB2 index"),
        zaxis = list(title = "BB3 index")
      )
    )
  
  saveWidget(
    p3d,
    file = file.path(outdir, paste0(safe_filename(tg), "_3D_scatter.html")),
    selfcontained = FALSE
  )
}

cat(
  "Finished: ", as.character(Sys.time()), "\n",
  file = run_info_file,
  append = TRUE,
  sep = ""
)

message("Done. Plots written to:")
message(outdir)