#!/bin/bash
#SBATCH --job-name=combine_parts
#SBATCH --partition=cpu_standard
#SBATCH --cpus-per-task=2
#SBATCH --mem=32G
#SBATCH --time=04:00:00
#SBATCH --output=/home/prp50ch/DEL_analysis_5/logs/combine_parts_%j.out
#SBATCH --error=/home/prp50ch/DEL_analysis_5/logs/combine_parts_%j.err

mkdir -p /home/prp50ch/DEL_analysis_4/logs
mkdir -p /home/prp50ch/DEL_analysis_4/results
mkdir -p /home/prp50ch/DEL_analysis_4/results/combined_parquet_parts

cd /home/prp50ch/DEL_analysis_4/tools || exit 1

echo "Started at: $(date)"
echo "Running on: $(hostname)"
echo "Working directory: $(pwd)"
echo "R script exists?"
ls -lh /home/prp50ch/DEL_analysis_5/tools/00_combine_RData_to_parquet_parts.R

/usr/bin/Rscript /home/prp50ch/DEL_analysis_4/tools/00_combine_RData_to_parquet_parts.R

echo "Finished at: $(date)"