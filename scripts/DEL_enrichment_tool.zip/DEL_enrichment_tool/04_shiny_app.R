library(shiny)
library(readxl)
library(tidyverse)
library(plotly)
library(DT)

# -----------------------------
# Input file
# -----------------------------
RESULTS_FILE <- "/home/prp50ch/DEL_analysis_3/results/DEL_enrichment_results.xlsx"

# -----------------------------
# Helper
# -----------------------------
fix_num <- function(x) {
  if (is.list(x)) as.numeric(unlist(x)) else as.numeric(x)
}

# -----------------------------
# Load data once
# -----------------------------
df_raw <- read_excel(RESULTS_FILE, sheet = "molecule_scores") |>
  mutate(
    pseudocount = fix_num(pseudocount),
    target_mean_per_mil = fix_num(target_mean_per_mil),
    native_mean_per_mil = fix_num(native_mean_per_mil),
    target_vs_native = fix_num(target_vs_native),
    corrected_score = fix_num(corrected_score),
    target_vs_mean_control = if ("target_vs_mean_control" %in% names(.)) {
      fix_num(target_vs_mean_control)
    } else {
      NA_real_
    }
  )

score_columns <- names(df_raw)[
  names(df_raw) %in% c(
    "corrected_score",
    "target_vs_native",
    "target_vs_mean_control"
  ) |
    str_starts(names(df_raw), "target_vs_")
]

score_columns <- unique(score_columns)

targets <- sort(unique(df_raw$target))
pseudocounts <- sort(unique(df_raw$pseudocount))

# -----------------------------
# UI
# -----------------------------
ui <- fluidPage(
  titlePanel("DEL 3D Scatter Plot Explorer"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput(
        "target",
        "Target protein:",
        choices = targets,
        selected = targets[1]
      ),
      
      selectInput(
        "pseudocount",
        "Pseudocount:",
        choices = pseudocounts,
        selected = pseudocounts[1]
      ),
      
      selectInput(
        "score_col",
        "Score / log2FC used for colour and filtering:",
        choices = score_columns,
        selected = if ("corrected_score" %in% score_columns) "corrected_score" else score_columns[1]
      ),
      
      sliderInput(
        "min_cpm",
        "Minimum target CPM:",
        min = 0,
        max = 100,
        value = 10,
        step = 1
      ),
      
      uiOutput("score_range_ui"),
      
      checkboxInput(
        "use_range",
        "Use score range instead of only minimum cutoff",
        value = FALSE
      ),
      
      actionButton(
        "go",
        "Update 3D plot",
        class = "btn-primary"
      ),
      
      br(), br(),
      
      helpText(
        "The 3D axes represent BB1, BB2, and BB3. Colour is the selected score as a continuous gradient. Use the cutoff/range to display only selected score values."
      )
    ),
    
    mainPanel(
      plotlyOutput("plot3d", height = "760px"),
      hr(),
      h4("Clicked point"),
      verbatimTextOutput("clicked_point"),
      hr(),
      h4("Filtered molecules shown in plot"),
      DTOutput("table")
    )
  )
)

# -----------------------------
# Server
# -----------------------------
server <- function(input, output, session) {
  
  # Dynamically update score range based on target + pseudocount + score column
  output$score_range_ui <- renderUI({
    req(input$target, input$pseudocount, input$score_col)
    
    d <- df_raw |>
      filter(
        target == input$target,
        pseudocount == as.numeric(input$pseudocount)
      ) |>
      mutate(score_value = fix_num(.data[[input$score_col]])) |>
      filter(!is.na(score_value))
    
    if (nrow(d) == 0) {
      return(helpText("No score values available for this selection."))
    }
    
    min_score <- floor(min(d$score_value, na.rm = TRUE))
    max_score <- ceiling(max(d$score_value, na.rm = TRUE))
    
    tagList(
      sliderInput(
        "score_min",
        "Minimum score / log2FC cutoff:",
        min = min_score,
        max = max_score,
        value = max(1, min_score),
        step = 0.1
      ),
      sliderInput(
        "score_range",
        "Score / log2FC range:",
        min = min_score,
        max = max_score,
        value = c(max(1, min_score), max_score),
        step = 0.1
      )
    )
  })
  
  filtered_data <- eventReactive(input$go, {
    req(input$target, input$pseudocount, input$score_col)
    
    d <- df_raw |>
      filter(
        target == input$target,
        pseudocount == as.numeric(input$pseudocount)
      ) |>
      mutate(
        score_value = fix_num(.data[[input$score_col]])
      ) |>
      filter(
        !is.na(score_value),
        !is.na(target_mean_per_mil),
        target_mean_per_mil >= input$min_cpm,
        !is.na(BB1_name),
        !is.na(BB2_name),
        !is.na(BB3_name)
      )
    
    if (isTRUE(input$use_range)) {
      req(input$score_range)
      d <- d |>
        filter(
          score_value >= input$score_range[1],
          score_value <= input$score_range[2]
        )
    } else {
      req(input$score_min)
      d <- d |>
        filter(score_value >= input$score_min)
    }
    
    validate(
      need(nrow(d) > 0, "No molecules pass the selected filters. Lower the CPM or score cutoff.")
    )
    
    # Numbered axes for categorical BB names
    bb1_levels <- sort(unique(d$BB1_name))
    bb2_levels <- sort(unique(d$BB2_name))
    bb3_levels <- sort(unique(d$BB3_name))
    
    d |>
      mutate(
        BB1_index = as.integer(factor(BB1_name, levels = bb1_levels)),
        BB2_index = as.integer(factor(BB2_name, levels = bb2_levels)),
        BB3_index = as.integer(factor(BB3_name, levels = bb3_levels)),
        hover_text = paste0(
          "Target: ", target,
          "<br>BB1: ", BB1_name,
          "<br>BB1 SMILES: ", BB1_smiles,
          "<br>BB2: ", BB2_name,
          "<br>BB2 SMILES: ", BB2_smiles,
          "<br>BB3: ", BB3_name,
          "<br>BB3 SMILES: ", BB3_smiles,
          "<br>Target CPM: ", round(target_mean_per_mil, 3),
          "<br>Native CPM: ", round(native_mean_per_mil, 3),
          "<br>", input$score_col, ": ", round(score_value, 3),
          "<br>Corrected score: ", round(corrected_score, 3),
          "<br>Target vs native: ", round(target_vs_native, 3),
          "<br>Target vs mean control: ", round(target_vs_mean_control, 3),
          "<br>Limiting control: ", limiting_control,
          "<br>Pseudocount: ", pseudocount
        )
      )
  }, ignoreInit = FALSE)
  
  output$plot3d <- renderPlotly({
    d <- filtered_data()
    
    plot_ly(
      data = d,
      x = ~BB1_index,
      y = ~BB2_index,
      z = ~BB3_index,
      type = "scatter3d",
      mode = "markers",
      text = ~hover_text,
      hoverinfo = "text",
      source = "del3d",
      marker = list(
        size = 5,
        color = ~score_value,
        colorscale = "Viridis",
        showscale = TRUE,
        opacity = 0.85,
        colorbar = list(title = input$score_col)
      )
    ) |>
      layout(
        title = paste0(
          input$target,
          " | 3D BB1-BB2-BB3 scatter | score = ",
          input$score_col
        ),
        scene = list(
          xaxis = list(title = "BB1 index"),
          yaxis = list(title = "BB2 index"),
          zaxis = list(title = "BB3 index")
        )
      )
  })
  
  output$clicked_point <- renderPrint({
    click <- event_data("plotly_click", source = "del3d")
    
    if (is.null(click)) {
      return("Click a point in the 3D plot to display details.")
    }
    
    d <- filtered_data()
    
    # Find nearest plotted point based on coordinates
    clicked <- d |>
      filter(
        BB1_index == click$x,
        BB2_index == click$y,
        BB3_index == click$z
      ) |>
      slice(1)
    
    if (nrow(clicked) == 0) {
      return("Clicked point not found.")
    }
    
    cat("Target:", clicked$target, "\n")
    cat("BB1:", clicked$BB1_name, "\n")
    cat("BB1 SMILES:", clicked$BB1_smiles, "\n")
    cat("BB2:", clicked$BB2_name, "\n")
    cat("BB2 SMILES:", clicked$BB2_smiles, "\n")
    cat("BB3:", clicked$BB3_name, "\n")
    cat("BB3 SMILES:", clicked$BB3_smiles, "\n")
    cat("Target CPM:", round(clicked$target_mean_per_mil, 3), "\n")
    cat("Native CPM:", round(clicked$native_mean_per_mil, 3), "\n")
    cat(input$score_col, ":", round(clicked$score_value, 3), "\n")
    cat("Corrected score:", round(clicked$corrected_score, 3), "\n")
    cat("Target vs native:", round(clicked$target_vs_native, 3), "\n")
    cat("Target vs mean control:", round(clicked$target_vs_mean_control, 3), "\n")
    cat("Limiting control:", clicked$limiting_control, "\n")
    cat("Pseudocount:", clicked$pseudocount, "\n")
  })
  
  output$table <- renderDT({
    d <- filtered_data() |>
      select(
        target,
        pseudocount,
        BB1_name, BB1_smiles,
        BB2_name, BB2_smiles,
        BB3_name, BB3_smiles,
        target_mean_per_mil,
        native_mean_per_mil,
        selected_score = score_value,
        corrected_score,
        target_vs_native,
        target_vs_mean_control,
        limiting_control
      ) |>
      arrange(desc(selected_score))
    
    datatable(
      d,
      options = list(
        pageLength = 20,
        scrollX = TRUE
      )
    )
  })
}

shinyApp(ui, server)