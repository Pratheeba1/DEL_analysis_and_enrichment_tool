library(tidyverse)
library(arrow)

input_dir <- "/home/prp50ch/DEL_analysis_4/results"
output_dir <- "/home/prp50ch/DEL_analysis_4/results/combined_parquet_parts"

dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

rdata_files <- list.files(
  input_dir,
  pattern = "^result_dataset_.*\\.RData$",
  full.names = TRUE
)

cat("Found", length(rdata_files), "RData files\n")

read_one_rdata <- function(file) {
  cat("Reading:", basename(file), "\n")
  
  env <- new.env()
  load(file, envir = env)
  
  if (!exists("result_dataset", envir = env)) {
    stop("Object result_dataset not found in: ", file)
  }
  
  df <- get("result_dataset", envir = env) |> as_tibble()
  
  required_cols <- c(
    "ProteinCode1_name",
    "Region1Code_name", "Region1Code_smile", "Region1Code_code", "Region1Code_Errors",
    "Region2Code_name", "Region2Code_smile", "Region2Code_code", "Region2Code_Errors",
    "Region3Code_name", "Region3Code_smile", "Region3Code_code", "Region3Code_Errors",
    "SumOfErrors"
  )
  
  # Ensure required columns exist
  missing_cols <- setdiff(required_cols, names(df))
  if (length(missing_cols) > 0) {
    stop("Missing columns in ", basename(file), ": ", paste(missing_cols, collapse = ", "))
  }
  
  # Select + add source_file FIRST (important)
  df <- df |>
    select(all_of(required_cols)) |>
    mutate(source_file = basename(file))
  
  # Rename AFTER adding source_file
  df <- df |>
    rename(
      sample = ProteinCode1_name,
      
      BB1_name = Region1Code_name,
      BB1_smiles = Region1Code_smile,
      BB1_code = Region1Code_code,
      BB1_errors = Region1Code_Errors,
      
      BB2_name = Region2Code_name,
      BB2_smiles = Region2Code_smile,
      BB2_code = Region2Code_code,
      BB2_errors = Region2Code_Errors,
      
      BB3_name = Region3Code_name,
      BB3_smiles = Region3Code_smile,
      BB3_code = Region3Code_code,
      BB3_errors = Region3Code_Errors
    )
  
  return(df)
}

for (file in rdata_files) {
  df <- read_one_rdata(file)
  
  out_file <- file.path(
    output_dir,
    paste0(tools::file_path_sans_ext(basename(file)), ".parquet")
  )
  
  write_parquet(df, out_file)
  
  cat("Written:", out_file, "\n")
  
  rm(df)
  gc()
}

cat("Done. Parquet dataset written to:\n", output_dir, "\n")