rm(list = ls())

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  stop("Usage: Rscript check_R1_R2_percentages.R <sample_name> [max_reads]")
}

sample_name <- args[1]

if (is.na(sample_name) || sample_name == "" || sample_name == "NA") {
  stop("sample_name is empty. Submit with: SAMPLE_NAME=CellAminus MAX_READS=50000 sbatch check_R1_R2_percentages_SLURM.sh")
}

max_reads <- ifelse(length(args) >= 2, as.integer(args[2]), NA)

library(readxl)
library(ShortRead)
library(Biostrings)
library(seqinr)
library(magrittr)
library(dplyr)
library(gtools)
library(stringr)

# helper functions
analyze_dataset <- source("ClusterCode/analyze_datasets.R")$value
get_sequence_start <- source("ClusterCode/get_sequence_start.R")$value
get_indices_dataset <- source("ClusterCode/get_indices_dataset.R")$value
check_single_code <- source("ClusterCode/check_single_code.R")$value
check_single_code_for_insertion <- source("ClusterCode/check_single_code_for_insertion.R")$value
check_single_code_for_miss_element <- source("ClusterCode/check_single_code_for_miss_element.R")$value
check_for_combined_errors <- source("ClusterCode/check_for_combined_errors.R")$value
analyze_sequence_onesheet <- source("ClusterCode/analyze_sequence_onesheet.R")$value
sheet_info <- source("ClusterCode/sheet_info.R")$value
comparing_all_patterns_onesheet <- source("ClusterCode/comparing_all_patterns_onesheet.R")$value

structure_sheet <- read_excel("../data/structure_sheet.xlsx") |>
  mutate(across(where(is.character), trimws))

sample_dir <- file.path("../data", sample_name)

if (!dir.exists(sample_dir)) {
  stop("Sample folder not found: ", sample_dir)
}

protein_row <- which(structure_sheet$ProteinCode1_name == sample_name)

if (length(protein_row) != 1) {
  stop("Could not uniquely match sample in structure sheet: ", sample_name)
}

sheet_inf <- sheet_info("MVDEL_1", structure_sheet, protein_row, prime_length = 8)

fastq_files <- list.files(
  sample_dir,
  pattern = "\\.fq\\.gz$",
  full.names = TRUE
)

if (length(fastq_files) == 0) {
  stop("No .fq.gz files found in: ", sample_dir)
}

fastq_files <- sort(fastq_files)

summary_list <- list()

for (fastq_file in fastq_files) {
  
  cat("====================================\n")
  cat("Sample:", sample_name, "\n")
  cat("Testing FASTQ:", fastq_file, "\n")
  cat("====================================\n")
  
  data_fastq <- readFastq(fastq_file)
  total_reads_in_file <- length(data_fastq)
  
  if (!is.na(max_reads)) {
    n_use <- min(max_reads, total_reads_in_file)
    data_fastq <- data_fastq[seq_len(n_use)]
  }
  
  reads_used <- length(data_fastq)
  
  matching_indices <- get_indices_dataset(reads_used, step = 100000)
  all_results <- vector("list", nrow(matching_indices))
  
  for (p in seq_len(nrow(matching_indices))) {
    cat("Processing chunk", p, "of", nrow(matching_indices), "\n")
    
    sequences_dataset <- data_fastq@sread[
      matching_indices[p, 1]:matching_indices[p, 2]
    ]
    
    chunk_result <- analyze_dataset(
      sequences_dataset = sequences_dataset,
      sheet_inf = sheet_inf,
      thresholds_two_errors = 20,
      error_threshold = 2
    )
    
    all_results[[p]] <- chunk_result
    
    rm(sequences_dataset, chunk_result)
    gc()
  }
  
  result_tmp <- bind_rows(all_results)
  
  r1_good <- sum(result_tmp$Region1Code_smile != "No Smile", na.rm = TRUE)
  r2_good <- sum(result_tmp$Region2Code_smile != "No Smile", na.rm = TRUE)
  r3_good <- sum(result_tmp$Region3Code_smile != "No Smile", na.rm = TRUE)
  
  score <- r1_good + r2_good + r3_good
  
  summary_df <- tibble(
    sample = sample_name,
    fastq_file = basename(fastq_file),
    fastq_path = fastq_file,
    total_reads_in_file = total_reads_in_file,
    reads_used = reads_used,
    Region1_good = r1_good,
    Region1_percent = round(100 * r1_good / reads_used, 4),
    Region2_good = r2_good,
    Region2_percent = round(100 * r2_good / reads_used, 4),
    Region3_good = r3_good,
    Region3_percent = round(100 * r3_good / reads_used, 4),
    total_score = score
  )
  
  print(summary_df)
  
  summary_list[[basename(fastq_file)]] <- summary_df
  
  rm(data_fastq, result_tmp, all_results)
  gc()
}

final_summary <- bind_rows(summary_list)

out_file <- file.path(
  "../results",
  paste0("R1_R2_check_", sample_name, ".csv")
)

write.csv(final_summary, out_file, row.names = FALSE)

cat("====================================\n")
cat("Saved summary:", out_file, "\n")
cat("====================================\n")
print(final_summary)