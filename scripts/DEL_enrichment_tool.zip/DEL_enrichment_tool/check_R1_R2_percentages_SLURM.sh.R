#!/bin/bash
#SBATCH --job-name=check_R1_R2
#SBATCH --partition=test
#SBATCH --mem=2G
#SBATCH --time=00:30:00
#SBATCH --output=../logs/check_R1_R2_%j.out
#SBATCH --error=../logs/check_R1_R2_%j.err

cd ~/DEL_analysis_5/tools || exit 1

mkdir -p ../logs
mkdir -p ../results

module load R

echo "Started at: $(date)"
echo "Running on: $(hostname)"
echo "Sample: $SAMPLE_NAME"
echo "Max reads: $MAX_READS"

Rscript check_R1_R2_percentages.R "$SAMPLE_NAME" "$MAX_READS"

echo "Finished at: $(date)"