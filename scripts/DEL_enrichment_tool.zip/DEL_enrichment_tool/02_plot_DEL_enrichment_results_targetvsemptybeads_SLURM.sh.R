#!/bin/bash
#SBATCH --job-name=DEL_plots_empty
#SBATCH --partition=cpu_standard
#SBATCH --cpus-per-task=2
#SBATCH --mem=32G
#SBATCH --time=04:00:00
#SBATCH --output=/home/prp50ch/DEL_analysis_5/logs/DEL_plots_empty_%j.out
#SBATCH --error=/home/prp50ch/DEL_analysis_5/logs/DEL_plots_empty_%j.err

mkdir -p /home/prp50ch/DEL_analysis_5/logs
mkdir -p /home/prp50ch/DEL_analysis_5/results

cd /home/prp50ch/DEL_analysis_5/tools || exit 1

echo "Started at: $(date)"
echo "Running on: $(hostname)"
echo "Working directory: $(pwd)"

/usr/bin/Rscript /home/prp50ch/DEL_analysis_5/tools/02_plot_DEL_enrichment_results_targetvsemptybeads.R

echo "Finished at: $(date)"