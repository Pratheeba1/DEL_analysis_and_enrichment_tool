#!/bin/bash
#SBATCH --job-name=DEL_enrich
#SBATCH --partition=cpu_standard
#SBATCH --cpus-per-task=2
#SBATCH --mem=64G
#SBATCH --time=06:00:00
#SBATCH --output=/home/prp50ch/DEL_analysis_5/logs/DEL_enrich_%j.out
#SBATCH --error=/home/prp50ch/DEL_analysis_5/logs/DEL_enrich_%j.err

mkdir -p /home/prp50ch/DEL_analysis_5/logs
mkdir -p /home/prp50ch/DEL_analysis_5/results

cd /home/prp50ch/DEL_analysis_5/tools || exit 1

echo "Started at: $(date)"
echo "Running on: $(hostname)"
echo "Working directory: $(pwd)"

echo "Checking input files..."
ls -lh /home/prp50ch/DEL_analysis_4/data/annotation_sheet.xlsx
ls -ld /home/prp50ch/DEL_analysis_4/results/combined_parquet_parts

/usr/bin/Rscript /home/prp50ch/DEL_analysis_4/tools/01_run_DEL_enrichment_pipeline_arrow_count.R

echo "Finished at: $(date)"