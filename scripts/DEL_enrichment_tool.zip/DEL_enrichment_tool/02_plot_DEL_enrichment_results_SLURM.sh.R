#!/bin/bash
#SBATCH --job-name=DEL_plot_test
#SBATCH --partition=cpu_standard
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G
#SBATCH --time=10:00:00
#SBATCH --output=/home/prp50ch/DEL_analysis_5/logs/DEL_plot_test_%j.out
#SBATCH --error=/home/prp50ch/DEL_analysis_5/logs/DEL_plot_test_%j.err

mkdir -p /home/prp50ch/DEL_analysis_5/logs
mkdir -p /home/prp50ch/DEL_analysis_5/results

cd /home/prp50ch/DEL_analysis_5/tools || exit 1

echo "Started at: $(date)"
echo "Running on: $(hostname)"
echo "Working directory: $(pwd)"

/usr/bin/Rscript /home/prp50ch/DEL_analysis_5/tools/02_plot_DEL_enrichment_results.R

echo "Finished at: $(date)"