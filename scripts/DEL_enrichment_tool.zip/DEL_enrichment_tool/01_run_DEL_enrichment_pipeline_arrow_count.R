library(tidyverse)
library(arrow)
library(readxl)
library(writexl)

# -----------------------------
# Input / output
# -----------------------------
combined_parquet_dir <- "/home/prp50ch/DEL_analysis_4/results/combined_parquet_parts"
annotation_file <- "/home/prp50ch/DEL_analysis_4/data/annotation_sheet.xlsx"

output_excel <- "/home/prp50ch/DEL_analysis_4/results/DEL_enrichment_results_summary.xlsx"

output_molecule_parquet <- "/home/prp50ch/DEL_analysis_4/results/molecule_scores_all.parquet"
output_control_parquet <- "/home/prp50ch/DEL_analysis_4/results/control_scores_long_all.parquet"

pseudocounts <- c(1, 0.1)

# -----------------------------
# Helper functions
# -----------------------------
safe_max <- function(x) {
  if (all(is.na(x))) NA_real_ else max(x, na.rm = TRUE)
}

safe_median <- function(x) {
  if (all(is.na(x))) NA_real_ else median(x, na.rm = TRUE)
}

# -----------------------------
# Read inputs
# -----------------------------
message("Opening combined parquet dataset...")
del_ds <- open_dataset(combined_parquet_dir)

message("Reading annotation sheet...")
anno <- read_excel(annotation_file) |>
  mutate(
    sample = as.character(sample),
    target = as.character(target),
    sample_role = tolower(as.character(sample_role)),
    control_type = as.character(control_type),
    native_group = as.character(native_group),
    replicate = as.character(replicate),
    include = as.logical(include)
  ) |>
  filter(include == TRUE)

# -----------------------------
# Basic checks
# -----------------------------
required_del_cols <- c(
  "sample",
  "BB1_name", "BB1_smiles", "BB1_code", "BB1_errors",
  "BB2_name", "BB2_smiles", "BB2_code", "BB2_errors",
  "BB3_name", "BB3_smiles", "BB3_code", "BB3_errors",
  "SumOfErrors",
  "source_file"
)

missing_del <- setdiff(required_del_cols, names(del_ds))
if (length(missing_del) > 0) {
  stop("Missing columns in parquet dataset: ", paste(missing_del, collapse = ", "))
}

required_anno_cols <- c(
  "sample", "target", "sample_role", "control_type",
  "native_group", "replicate", "include"
)

missing_anno <- setdiff(required_anno_cols, names(anno))
if (length(missing_anno) > 0) {
  stop("Missing columns in annotation sheet: ", paste(missing_anno, collapse = ", "))
}

# -----------------------------
# Count clean decoded molecules directly from Arrow
# -----------------------------
message("Counting clean decoded molecules...")

counts <- del_ds |>
  select(all_of(required_del_cols)) |>
  filter(
    sample %in% anno$sample,
    BB1_name != "No Name",
    BB2_name != "No Name",
    BB3_name != "No Name",
    BB1_code != "No Code",
    BB2_code != "No Code",
    BB3_code != "No Code",
    BB1_smiles != "No Smile",
    BB2_smiles != "No Smile",
    BB3_smiles != "No Smile"
  ) |>
  group_by(
    sample,
    BB1_name, BB1_smiles, BB1_code,
    BB2_name, BB2_smiles, BB2_code,
    BB3_name, BB3_smiles, BB3_code
  ) |>
  summarise(
    count = n(),
    .groups = "drop"
  ) |>
  collect() |>
  inner_join(anno, by = "sample")

message("Molecule count rows collected: ", nrow(counts))

missing_samples <- setdiff(unique(anno$sample), unique(counts$sample))
if (length(missing_samples) > 0) {
  warning(
    "These annotation samples had no clean decoded rows:\n",
    paste(missing_samples, collapse = ", ")
  )
}

# -----------------------------
# Normalize to counts per million
# -----------------------------
message("Normalizing to CPM/per_mil...")

counts_norm <- counts |>
  group_by(sample) |>
  mutate(
    total_reads_sample = sum(count),
    per_mil = 1e6 * count / total_reads_sample
  ) |>
  ungroup()

# -----------------------------
# Aggregate replicates
# Missing molecules in a replicate are treated as zero
# -----------------------------
message("Aggregating replicates with zero-aware means...")

condition_n <- anno |>
  count(
    target,
    sample_role,
    control_type,
    native_group,
    name = "n_expected_replicates"
  )

agg <- counts_norm |>
  summarize(
    sum_per_mil = sum(per_mil),
    sumsq_per_mil = sum(per_mil^2),
    n_observed_replicates = n_distinct(sample),
    .by = c(
      target,
      sample_role,
      control_type,
      native_group,
      BB1_name, BB1_smiles, BB1_code,
      BB2_name, BB2_smiles, BB2_code,
      BB3_name, BB3_smiles, BB3_code
    )
  ) |>
  left_join(
    condition_n,
    by = c("target", "sample_role", "control_type", "native_group")
  ) |>
  mutate(
    mean_per_mil = sum_per_mil / n_expected_replicates,
    sd_per_mil = case_when(
      n_expected_replicates <= 1 ~ NA_real_,
      TRUE ~ sqrt(
        pmax(
          (sumsq_per_mil - n_expected_replicates * mean_per_mil^2) /
            (n_expected_replicates - 1),
          0
        )
      )
    ),
    n_replicates = n_expected_replicates
  )

# -----------------------------
# Split target / native / control
# -----------------------------
target_tbl <- agg |>
  filter(sample_role == "target") |>
  select(
    target,
    native_group,
    BB1_name, BB1_smiles, BB1_code,
    BB2_name, BB2_smiles, BB2_code,
    BB3_name, BB3_smiles, BB3_code,
    target_mean_per_mil = mean_per_mil,
    target_sd_per_mil = sd_per_mil,
    target_n_replicates = n_replicates
  )

# Native table is joined by native_group, not target
native_tbl <- agg |>
  filter(sample_role == "native") |>
  summarize(
    native_mean_per_mil = mean(mean_per_mil, na.rm = TRUE),
    native_sd_per_mil = mean(sd_per_mil, na.rm = TRUE),
    native_n_replicates = max(n_replicates, na.rm = TRUE),
    .by = c(
      native_group,
      BB1_name, BB1_smiles, BB1_code,
      BB2_name, BB2_smiles, BB2_code,
      BB3_name, BB3_smiles, BB3_code
    )
  )

control_tbl <- agg |>
  filter(sample_role == "control") |>
  select(
    target,
    native_group,
    control_type,
    BB1_name, BB1_smiles, BB1_code,
    BB2_name, BB2_smiles, BB2_code,
    BB3_name, BB3_smiles, BB3_code,
    control_mean_per_mil = mean_per_mil,
    control_sd_per_mil = sd_per_mil,
    control_n_replicates = n_replicates
  )

# Expected controls come from annotation sheet, not only observed molecules.
# This prevents fake target_vs_NA and ensures missing control molecules become zero.
control_design <- anno |>
  filter(sample_role == "control") |>
  distinct(target, native_group, control_type) |>
  filter(!is.na(control_type), control_type != "NA")

# -----------------------------
# Target + native base table
# -----------------------------
base_tbl <- target_tbl |>
  left_join(
    native_tbl,
    by = c(
      "native_group",
      "BB1_name", "BB1_smiles", "BB1_code",
      "BB2_name", "BB2_smiles", "BB2_code",
      "BB3_name", "BB3_smiles", "BB3_code"
    )
  ) |>
  mutate(
    native_mean_per_mil = replace_na(native_mean_per_mil, 0),
    native_sd_per_mil = replace_na(native_sd_per_mil, 0)
  )

# -----------------------------
# Calculate enrichment scores
# -----------------------------
message("Calculating enrichment scores...")

all_molecule_scores <- list()
all_control_scores_long <- list()

for (p in pseudocounts) {
  
  message("Calculating scores for pseudocount = ", p)
  
  # Target vs native
  base_scored <- base_tbl |>
    mutate(
      pseudocount = p,
      target_vs_native = log2((target_mean_per_mil + p) / (native_mean_per_mil + p))
    )
  
  # Target vs each expected control
  # Targets without controls are excluded from control-based scoring.
  control_scores <- base_scored |>
    left_join(
      control_design,
      by = c("target", "native_group")
    ) |>
    filter(!is.na(control_type), control_type != "NA") |>
    left_join(
      control_tbl,
      by = c(
        "target", "native_group", "control_type",
        "BB1_name", "BB1_smiles", "BB1_code",
        "BB2_name", "BB2_smiles", "BB2_code",
        "BB3_name", "BB3_smiles", "BB3_code"
      )
    ) |>
    mutate(
      control_mean_per_mil = replace_na(control_mean_per_mil, 0),
      control_sd_per_mil = replace_na(control_sd_per_mil, 0),
      score = log2((target_mean_per_mil + p) / (control_mean_per_mil + p)),
      comparison = paste0("target_vs_", control_type)
    )
  
  # Mean-control comparison
  mean_control_tbl <- control_scores |>
    summarize(
      mean_control_per_mil = mean(control_mean_per_mil, na.rm = TRUE),
      n_controls_for_mean = n_distinct(control_type),
      target_vs_mean_control = log2(
        (first(target_mean_per_mil) + p) /
          (mean(control_mean_per_mil, na.rm = TRUE) + p)
      ),
      .by = c(
        target, native_group,
        BB1_name, BB1_smiles, BB1_code,
        BB2_name, BB2_smiles, BB2_code,
        BB3_name, BB3_smiles, BB3_code,
        pseudocount
      )
    )
  
  # Strict corrected score = weakest target-vs-control comparison
  corrected <- control_scores |>
    summarize(
      corrected_score = min(score, na.rm = TRUE),
      limiting_control = control_type[which.min(score)],
      n_controls_used = n_distinct(control_type),
      .by = c(
        target, native_group,
        BB1_name, BB1_smiles, BB1_code,
        BB2_name, BB2_smiles, BB2_code,
        BB3_name, BB3_smiles, BB3_code,
        pseudocount
      )
    )
  
  # Individual target-vs-control scores as wide columns
  control_wide <- control_scores |>
    select(
      target, native_group,
      BB1_name, BB1_smiles, BB1_code,
      BB2_name, BB2_smiles, BB2_code,
      BB3_name, BB3_smiles, BB3_code,
      pseudocount,
      comparison,
      score
    ) |>
    pivot_wider(
      names_from = comparison,
      values_from = score
    )
  
  molecule_scores <- base_scored |>
    left_join(
      corrected,
      by = c(
        "target", "native_group",
        "BB1_name", "BB1_smiles", "BB1_code",
        "BB2_name", "BB2_smiles", "BB2_code",
        "BB3_name", "BB3_smiles", "BB3_code",
        "pseudocount"
      )
    ) |>
    left_join(
      mean_control_tbl,
      by = c(
        "target", "native_group",
        "BB1_name", "BB1_smiles", "BB1_code",
        "BB2_name", "BB2_smiles", "BB2_code",
        "BB3_name", "BB3_smiles", "BB3_code",
        "pseudocount"
      )
    ) |>
    left_join(
      control_wide,
      by = c(
        "target", "native_group",
        "BB1_name", "BB1_smiles", "BB1_code",
        "BB2_name", "BB2_smiles", "BB2_code",
        "BB3_name", "BB3_smiles", "BB3_code",
        "pseudocount"
      )
    ) |>
    arrange(target, pseudocount, desc(corrected_score), desc(target_vs_native))
  
  control_scores_long <- control_scores |>
    select(
      target,
      native_group,
      BB1_name, BB1_smiles, BB1_code,
      BB2_name, BB2_smiles, BB2_code,
      BB3_name, BB3_smiles, BB3_code,
      pseudocount,
      comparison,
      control_type,
      score,
      target_mean_per_mil,
      control_mean_per_mil,
      native_mean_per_mil,
      target_vs_native
    )
  
  all_molecule_scores[[as.character(p)]] <- molecule_scores
  all_control_scores_long[[as.character(p)]] <- control_scores_long
}

molecule_scores_all <- bind_rows(all_molecule_scores)
control_scores_long_all <- bind_rows(all_control_scores_long)

# -----------------------------
# Target summary
# -----------------------------
message("Creating target summary...")

target_summary <- molecule_scores_all |>
  summarize(
    n_molecules = n(),
    median_target_vs_native = safe_median(target_vs_native),
    median_corrected_score = safe_median(corrected_score),
    median_target_vs_mean_control = safe_median(target_vs_mean_control),
    max_corrected_score = safe_max(corrected_score),
    max_target_vs_mean_control = safe_max(target_vs_mean_control),
    n_hits_corrected_gt_1 = sum(corrected_score > 1, na.rm = TRUE),
    n_hits_mean_control_gt_1 = sum(target_vs_mean_control > 1, na.rm = TRUE),
    .by = c(target, native_group, pseudocount)
  )

limiting_summary <- molecule_scores_all |>
  filter(!is.na(limiting_control)) |>
  count(target, native_group, pseudocount, limiting_control, name = "n_limiting") |>
  group_by(target, native_group, pseudocount) |>
  mutate(frac_limiting = n_limiting / sum(n_limiting)) |>
  ungroup()

control_design_summary <- control_design |>
  arrange(target, native_group, control_type)

settings <- tibble(
  setting = c(
    "combined_parquet_dir",
    "annotation_file",
    "output_excel",
    "output_molecule_parquet",
    "output_control_parquet",
    "pseudocounts",
    "corrected_score_definition",
    "target_vs_mean_control_definition",
    "missing_native_molecules",
    "missing_control_molecules",
    "control_design_source"
  ),
  value = c(
    combined_parquet_dir,
    annotation_file,
    output_excel,
    output_molecule_parquet,
    output_control_parquet,
    paste(pseudocounts, collapse = ", "),
    "corrected_score = min(target_vs_each_control)",
    "target_vs_mean_control = log2((target_mean_per_mil + p) / (mean(control_mean_per_mil) + p))",
    "missing native molecules treated as 0 CPM",
    "missing control molecules treated as 0 CPM",
    "expected controls are taken from annotation sheet where sample_role == control"
  )
)

# -----------------------------
# Save large outputs as parquet
# -----------------------------
message("Saving molecule score table as parquet...")
write_parquet(
  molecule_scores_all,
  output_molecule_parquet
)

message("Saving control score table as parquet...")
write_parquet(
  control_scores_long_all,
  output_control_parquet
)

# -----------------------------
# Write Excel summaries only
# -----------------------------
message("Writing Excel summary output...")

write_xlsx(
  list(
    target_summary = target_summary,
    limiting_control_summary = limiting_summary,
    control_design_summary = control_design_summary,
    settings = settings
  ),
  output_excel
)

message("Done. Results written to:")
message(output_excel)
message(output_molecule_parquet)
message(output_control_parquet)