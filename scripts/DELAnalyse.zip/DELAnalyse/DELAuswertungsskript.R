#install.packages("name")
library("here")
library("xlsx")
library("dplyr")     
### dplyr überschreibt einzelne Funktionen von plyr,
### z.B. count, daher Verwendung von plyr::count
library("plyr")



setwd(here::here())
path <- getwd()
source("MergeData.R")
poolnr <- 3
MergeData(path,poolnr)

load(paste0("Merged_Cluster_DataObject_Pool",poolnr,".RData"))
source("enrichment_factor_calc.R")

enrichment(data,poolnr)

setwd(here::here())
path <- getwd()
load(paste0("Merged_Cluster_DataObject_Pool",poolnr,".RData"))
source("ShowEnrichmentResults.R")
ShowEnrichmentResults(data,path,poolnr)

