MergeData <- function(path,poolnr)
{
  setwd(paste0(path,"/ClusterResults"))
  
  data_objects <- list.files()
  l <- length(data_objects)
  temp.space <- new.env()
  load(data_objects[1], temp.space)
  data <- get(ls(temp.space), envir = temp.space)
  rm(temp.space)
  
  data_objects <- list.files()
  l <- length(data_objects)
  
  names <- numeric(l)
  
  
  for(i in 1:l){
    (x <- strsplit(strsplit(data_objects[i],"_")[[1]][3],"")[[1]])
    if(length(x) == 8)
    {
      names[i] <- as.numeric(x[8])
    }
    else if(length(x) == 9)
    {
      names[i] <- as.numeric(paste0(x[8],x[9]))
    }
  }
  names <- sort(names)  
  amount <- c()
  for(i in 1:max(names))
  {
    amount <- c(amount,1:table(names)[i])
  }
  
  data <- NULL
  for(i in 1:l)
  {
    temp.space <- new.env()
    load(paste0("result_dataset_protein",names[i],"_",amount[i],".RDATA"), temp.space)
    results_dataset <- get(ls(temp.space), envir = temp.space)
    if(is.null(data))
    {
      data <- results_dataset
    }
    else
    {
      data <- rbind(data,results_dataset)
    }
    rm(results_dataset)
    rm(temp.space)
    if(amount[i]==table(names)[names[i]])
    {
      print(names[i])
      setwd(path)
      colnames(data) <- read.csv2("ResultColnames.csv")[,2]
      setwd(paste0(path,"/Merged_DataObject"))
      save(data,file = paste0("Merged_DataObject_",names[i],".RData"))
      data <- NULL
      setwd(paste0(path,"/ClusterResults"))
    }
  }
  
  # Merge the merged Protein Datas
  
  setwd(paste0(path,"/Merged_DataObject"))
  ##
  data_objects <- list.files()
  l <- length(data_objects)
  temp.space <- new.env()
  load(data_objects[1], temp.space)
  data <- get(ls(temp.space), envir = temp.space)
  rm(temp.space)
  
  for(i in 2:l)
  {
    print(i)
    temp.space <- new.env()
    load(paste0("Merged_DataObject_",i,".RDATA"), temp.space)
    results_dataset <- get(ls(temp.space), envir = temp.space)
    data <- rbind(data,results_dataset)
    rm(results_dataset)
    rm(temp.space)
  }
  
  setwd(path)
  colnames(data) <- read.csv2("ResultColnames.csv")[,2]
  
  
  #### Clear out all Parts with no founded Starting Points:
  
  data <- data[which(data$Region1Code_code != "No Code Prime"),]
  save(data,file = paste0("Merged_Cluster_DataObject_Pool",poolnr,".RData"))
}
