enrichment <- function(results_dataset,poolnr)
{
  
  ###############################################################################
  ### Enrichmentfaktor-Berechnung, basierend auf GrafischeAuswertung...

  
  ### Spalten mit IDs
  IDs_dataset <- results_dataset %>% select(ends_with("_ID"))
  
  ### Spalten mit IDs ohne Zwischenteile
  blockIDs_dataset <- results_dataset %>% select(ends_with("ID")) %>%
    select(-starts_with("Zwischenteil"))
  
  ### Zaehle Haeufigkeiten der Konnektivitaeten
  anz.Konnekt <- plyr::count(blockIDs_dataset, vars = colnames(blockIDs_dataset))                           
  
  
  which.NoID <- unique(unlist(apply(anz.Konnekt[-ncol(blockIDs_dataset)], 2, 
                                    function(x)which(x == "No ID"))))
  anz.Konnekt <- anz.Konnekt[-which.NoID,]
  
  ### Zaehle Haeufigkeiten der Proteine
  Reads.Proteine <- plyr::count(IDs_dataset, "ProteinCode_ID")
  
  ###############################################################################
  ###                    Zentrale Berechnungsfunktion                         ###
  ###############################################################################
  ### calc.enrichment  - Berechnet den Enrichmentfaktor für jede Konnektivitaet
  ###
  ### Input            - Konnektivitaet          - eine Konnektivitaet fuer die 
  ###                                              der Faktor bestimmt werden
  ###                                              soll
  ###                  - count.KonnektivitaetIDs - absolute Haeufigkeiten aller 
  ###                                              Konnektivitaeten
  ###                  - count.Proteine          - absolute Hauefigkeiten der 
  ###                                              Proteine
  ###
  ### Output     - Matrix aus - Protein Reads
  ###                         - Reads der Kontrolle
  ###                         - Haeufigkeit der Konnektivitaet zusammen mit dem 
  ###                           Protein
  ###                         - Haeufigkeit der Konnektivitaet zusammen mit der 
  ###                           Kontrolle 
  ###                         - Anteil der Konnektivitaet am Aufkommen des 
  ###                           Proteins in Promille
  ###                         - Anteil der Konnektivitaet am Aufkommen der 
  ###                           Kontrolle in Promille 
  ###                         - Enrichment factor
  #####
  

  ### Ausfuehren der Funktion fuer alle Proteine ausser der Referenz
  calc.enrichment <- function(Konnektivitaet, count.KonnektivitaetIDs, 
                              count.Proteine,control.variable,amplifiedDEL){ 
    
    # protein_Id <- as.vector(table(Konnektivitaet[,1]))[-which( count.Proteine[,1] == control.variable)]
    protein_Id <- as.vector(table(Konnektivitaet[,1]))
    protein_count <- count.Proteine$freq[-which( count.Proteine[,1] == control.variable |  count.Proteine[,1] == which.amplifiedDEL)]
    reads.protein <- rep.int(protein_count,times = protein_Id)
    
    
    
    # Anzahl Reads der Kontrolle
    reads.control <- count.Proteine[which( count.Proteine[,1] == control.variable), 2]
    
    #Hauefigkeit der intressierenden Konnektivitaet
    freq.protein <- as.numeric(Konnektivitaet[,5]) 
    
    #Hauefigkeit der intressierenden Konnektivitaet in control
    PCode <- count.KonnektivitaetIDs[count.KonnektivitaetIDs[,1] == control.variable,]
    RegionPaste <- paste0(as.character(Konnektivitaet[,2]) ,as.character(Konnektivitaet[,3]) ,as.character(Konnektivitaet[,4]) )
    ProteinPaste <- paste0(as.character(PCode[,2]),as.character(PCode[,3]),as.character(PCode[,4]))
    
    amplifiedDELPaste <- paste0(as.character(amplifiedDEL[,2]),as.character(amplifiedDEL[,3]),as.character(amplifiedDEL[,4]))
    
    
    freq.control <- rep(NA,length(RegionPaste))
    freq.amplified<- rep(NA,length(RegionPaste))
    
    for(i in 1:length(RegionPaste))
    {
      whichControl <- c(which(RegionPaste[i] == ProteinPaste),NA)
      if(!is.na(whichControl[1]))
      {
        freq.control[i] <- as.numeric( PCode[whichControl[1],5])
      }
      whichAmplified <- c(which(RegionPaste[i] == amplifiedDELPaste),NA)
      if(!is.na(whichAmplified[1]))
      {
        freq.amplified[i] <- as.numeric( amplifiedDEL[whichAmplified[1],5])
      }
    }
    ################ Enrichment Factors Methode 1: ################
    #Promille Anteil Konnektivitaet im intressierenden Protein
    promille.protein <- freq.protein / reads.protein * 1000
    
    #Promille Anteil Konnektivitaet in control
    promille.control <- freq.control / reads.control * 1000
    # 
    # #Berechnung des Enrichment Factors
    # enrichmentFactor <- promille.protein / promille.control
    #################################################################
    
    ################ Enrichment Factors Methode 2: ################
    enrichmentFactor <- (Konnektivitaet[,5] - freq.control) / freq.amplified
    
    # enrichmentFactor <- enrichmentFactor[!is.na(enrichmentFactor)]
    ###############################################################
    
    
    return(cbind(reads.protein, reads.control, freq.protein, freq.control, 
                 promille.protein, promille.control, enrichmentFactor))
    
  }
  
  Proteinnames <- names(table(results_dataset$ProteinCode_ID))
  control.variables <- Proteinnames[is.na(as.numeric(Proteinnames))]
  
  which.amplifiedDEL <- Proteinnames[unique(results_dataset$ProteinCode_name) == "Amplified DEL (Exp. 17)"]
  
  control.variables <- control.variables[control.variables != which.amplifiedDEL]
  
  #####################
  for(i in 1:length(control.variables))
  {
    print(i)
    Konnektivitaet = anz.Konnekt[-which((anz.Konnekt$ProteinCode_ID == control.variables[i])|(anz.Konnekt$ProteinCode_ID == which.amplifiedDEL)),]
    control.variable <- control.variables[i]
    Enrichment <- calc.enrichment(Konnektivitaet, 
                                  anz.Konnekt, 
                                  Reads.Proteine,
                                  control.variable,
                                  anz.Konnekt[which(anz.Konnekt$ProteinCode_ID == which.amplifiedDEL),])
    
    
    df.Enrichment <- as.data.frame(Enrichment)
    
    ### Anpassen der Spaltennamen
    colnames(df.Enrichment) <- c("reads.protein", "reads.control", "freq.protein", 
                                 "freq.control", "promille.protein", 
                                 "promille.control", "enrichmentFactor")
    
    
    
    ### Hinzufuegen des berechneten Enrichments zu den IDs ohne Kontrolle
    full.Enrichment <- cbind(anz.Konnekt[-which((anz.Konnekt$ProteinCode_ID == control.variable)|(anz.Konnekt$ProteinCode_ID == which.amplifiedDEL)),-5], df.Enrichment)
    
    missing_control <-  which(!is.na(full.Enrichment$freq.control))
    full.Enrichment <- full.Enrichment[missing_control,]
    Konnektivitaet <- Konnektivitaet[missing_control,]
    
    missing_Region3 <- full.Enrichment$Region3Code_ID !="No ID"
    full.Enrichment <- full.Enrichment[missing_Region3,]
    Konnektivitaet <- Konnektivitaet[missing_Region3,]
    
    missing_enrichment <- !is.na(full.Enrichment$enrichmentFactor)
    full.Enrichment <- full.Enrichment[missing_enrichment,]
    Konnektivitaet <- Konnektivitaet[missing_enrichment,]
    
    
    
    
    ### Bestimmen der Raenge der Haeufigkeiten 
    # Raenge werden so vergeben, dass die geringste Abundance auch den geringsten
    # Rang erhaelt
    # rank.Abundance <- rank(Konnektivitaet$freq)
    
    proteins <- levels(Konnektivitaet$ProteinCode_ID)[!levels(Konnektivitaet$ProteinCode_ID) %in% c(control.variable,which.amplifiedDEL)]
    rank.Abundance <- numeric(nrow(Konnektivitaet))
    for(i in proteins)
    {
      rank.Abundance[which(Konnektivitaet$ProteinCode_ID == i)] <- rank(Konnektivitaet$freq[which(Konnektivitaet$ProteinCode_ID == i)])
    }
    Konnektivitaet$rank <- rank.Abundance
    
    full.Enrichment$rank.Abundance <- rank.Abundance
    
    ### Abspeichern der Ergebnisse mit verallgemeinertem Dateinamen
    # 
    full.Enrichment <- full.Enrichment[!is.na(full.Enrichment$enrichmentFactor),]
    save(full.Enrichment, file = paste0("Enrichment_results/Enrichment_results_",control.variable,"_Pool_",poolnr,".RData"))
  }
}