setwd(here::here())
path <- getwd()
setwd(paste0(path,"/Merged_Controls"))
library("xlsx")
n <- 16
sum_protein_combinations <- numeric(n)
length_protein_combinations <- numeric(n)
for(i in 1:16)
{
  print(i)
  data <- read.xlsx(paste0("merged_enrichment",i,".xlsx"),sheetIndex = 1)
  sum_protein_combinations[i] <- sum(data$freq.protein)
  length_protein_combinations[i] <- length(data$freq.protein)
}
sum(length_protein_combinations)
i=1
