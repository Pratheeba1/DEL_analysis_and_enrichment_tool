ShowEnrichmentResults <- function(results_dataset,path,poolnr)
{
  Proteinnames <- names(table(results_dataset$ProteinCode_ID))
  
  
  control.variables <- Proteinnames[is.na(as.numeric(Proteinnames))]
  control.ids <- which(is.na(as.numeric(Proteinnames)))
  control.names <- as.vector(unique(results_dataset$ProteinCode_name)[is.na(as.numeric(Proteinnames))])
  
  which.amplifiedDEL <- which( control.names == "Amplified DEL (Exp. 17)" )
  control.variables <- control.variables[-which.amplifiedDEL]
  control.ids <- control.ids[-which.amplifiedDEL]
  control.names <- control.names[-which.amplifiedDEL]

  # Aufsplitten der Enrichmentfaktorberechnungen der einzelnen Kontrollgruppen 
  # anhand der Proteine
  
  for(i in 1:length(control.variables))
  {
    setwd(paste0(path,"/Enrichment_results"))
    temp.space <- new.env()
    load(paste0("Enrichment_results_",control.variables[i],"_Pool_",poolnr,".RData"), temp.space)
    enrichment.data <- cbind(get(ls(temp.space), envir = temp.space),control.names[i])
    colnames(enrichment.data)[13] <- "Control"
    rm(temp.space)

    split_enrichment <- split(enrichment.data,enrichment.data$ProteinCode_ID)

    setwd(paste0(path,"/",control.variables[i]))

    # s <- (1:length(Proteinnames))[-c(1,control.ids[i],which(is.na(as.numeric(Proteinnames)))[which.amplifiedDEL])]
    s <- (1:length(Proteinnames))[-c(1,control.ids[i],which(is.na(as.numeric(Proteinnames)))[which.amplifiedDEL])]
    split_data <-  vector(mode = "list",length = length(Proteinnames) - 1)
    split_data[[1]] <- list(as.data.frame(split_enrichment[[1]]) )
    for(j in 2:(length(s) + 1))
    {
      split_data[[j]] <- as.data.frame(split_enrichment[[j]])
    }
    # s <- s[s != control.ids[i]]
    s <- c(1,s)
    temp <- as.numeric(Proteinnames)
    Protein.ids <- c(temp[!is.na(temp)],control.ids)
    
    for (k in 1:length(s)){ write.xlsx(x = split_data[[k]],
                                 file = paste0("split_enrichment",s[Protein.ids[k]],".xlsx"), sheetName = Proteinnames[k],append = TRUE)
      gc()
    }
  }
  
  # Zusammenfügen der einzelnen Excelsheets zu den Kontrollgruppen anhand der
  # Proteinids
  
   for(i in (1:length(Proteinnames))[- which(is.na(as.numeric(Proteinnames)))[which.amplifiedDEL]])
  {
    if(i %in% control.ids)
    {
      # leftout <- unique(c(leftout,which(control.ids == i)))
      leftout <- which(control.ids == i)
      controls <- control.variables[-leftout]
    }
    else
    {
      controls <- control.variables
    }
    setwd(paste0(path,"/",controls[1]))
    protein <- read.xlsx(file = paste0("split_enrichment",i,".xlsx"),sheetIndex = 1)
    for(k in controls[-1])
    {
      setwd(paste0(path,"/",k))
      protein <- rbind(protein,read.xlsx(paste0("split_enrichment",i,".xlsx"),sheetIndex = 1))
    }
    setwd(paste0(path,"/Merged_Controls"))
    
    Proteinnames_temp <- as.numeric(Proteinnames)
    Proteinnames <- c(sort(Proteinnames_temp), Proteinnames[is.na(Proteinnames_temp)])
    
    write.xlsx(x = protein,
               file = paste0("merged_enrichment",i,".xlsx"), sheetName = Proteinnames[i],append = TRUE)
  }
}

