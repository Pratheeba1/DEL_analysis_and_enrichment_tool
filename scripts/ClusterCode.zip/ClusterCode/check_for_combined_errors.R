# sequence=given_sequence
# code_id= fused_data[categorial_index, 1]
# code_name=fused_data[categorial_index, 2]
# code= fused_data[categorial_index, 3]
# code_smiles=fused_data[categorial_index, 4]
# code_index=code_index
# code_length=lengths_parts[categorial_index]

  


check_for_combined_errors <- function(sequence, 
                                      code_id, 
                                      code_name,
                                      code, 
                                      code_smiles, 
                                      code_index,
                                      code_length) {
  ### Construction of vectors for comparison
  sequence_part_splitted <- strsplit(substr(sequence, code_index,
                                            code_index + code_length - 1),
                                     split = "")[[1]]

  code_splitted  <- strsplit(code, split = "")[[1]]
  ### Case at the end of the sequence: remainder of the sequence shorter than
  ### the intermediate part with the expected length
  if(length(sequence_part_splitted) < length(code_splitted)) {
    code_splitted <- code_splitted[1:length(sequence_part_splitted)]
    code_length <- length(code_splitted)
    code <- substr(code, 1, length(sequence_part_splitted))
  }

  #############################################################################
  ### Case of a shortened sequence: Deletion
  sequence_shortened <- head(sequence_part_splitted,
                             n = length(sequence_part_splitted) - 1)
  miss_combns_code   <- combinations(code_length, code_length - 1,
                                     code_splitted, set = FALSE)
  amount_combns  <- dim(miss_combns_code)[1]

  #############################################################################
  ### Case of an enlarged sequence: Insertion
  extended_versions_of_the_code <- c("X", code_splitted)
  for(i in 1:code_length)
    extended_versions_of_the_code <-
    rbind(extended_versions_of_the_code, append(code_splitted, "X",
                                                after = i))

  extended_sequence <- strsplit(substr(sequence, code_index,
                                       code_index + code_length),
                                split = "")[[1]]
  amount_extended_versions      <- dim(extended_versions_of_the_code)[1]

  #############################################################################
  ### Comparison vector for a missing element
  comparison_vec_miss <-
    vapply(seq(1, amount_combns),
           function(x)
             length(which(sequence_shortened !=
                            miss_combns_code[amount_combns - x + 1,])), 0)

  ### Case: Combined errors: Mutation and missing element
  if(attributes(adist(code, substr(sequence, code_index,
                                   code_index + code_length - 2),
                      counts = TRUE))[[2]][2] == 1 &&
     attributes(adist(code, substr(sequence, code_index,
                                   code_index + code_length - 2),
                      counts = TRUE))[[2]][3] == 1) {
    index_miss <- which.min(comparison_vec_miss)
    index_mutation <-
      which(sequence_shortened !=
              miss_combns_code[amount_combns - index_miss + 1,])
    if(index_mutation != index_miss)
      index_mutation  <- index_mutation[which(index_mutation != index_miss)]

    if(index_miss < index_mutation)
      return(c(code_id, code_name, code, code_smiles,
               "Missing Element / Mutation", index_miss, index_mutation,
               code_index + code_length - 1))
    else
      return(c(code_id, code_name, code, code_smiles,
               "Mutation / Missing Element", index_mutation, index_miss,
               code_index + code_length - 1))
  }

  ### Case : Combined errors: Insertion and Mutation
  if(length(extended_sequence) > length(sequence_part_splitted)) {
    comparison_vec_insertion <-
      vapply(seq(1, amount_extended_versions),
             function(x) length(which(extended_versions_of_the_code[x,] !=
                                        extended_sequence)), 0)

    if(attributes(adist(code, substr(sequence, code_index,
                                     code_index + code_length - 1),
                        counts = TRUE))[[2]][1] == 1 &&
       attributes(adist(code, substr(sequence, code_index,
                                     code_index + code_length - 1),
                        counts = TRUE))[[2]][3] == 1) {
      index_insertion <- which.min(comparison_vec_insertion)
      index_mutation  <- which(extended_sequence !=
                                 extended_versions_of_the_code[
                                   index_insertion,])

      index_mutation  <- index_mutation[which(index_mutation !=
                                                index_insertion)]

      if(length(index_mutation) == 1 && length(index_insertion) == 1) {
        if(index_insertion < index_mutation)
          return(c(code_id, code_name, code, code_smiles,
                   "Insertion / Mutation", index_insertion, index_mutation,
                   code_index + code_length + 1))
        else
          return(c(code_id, code_name, code, code_smiles,
                   "Mutation / Insertion", index_mutation, index_insertion,
                   code_index + code_length + 1))
      }
      else
        return(paste("No allowed combination found"))
    }

    ### Case: Combined errors: Insertion and deletion
    if(attributes(adist(code, substr(sequence, code_index,
                                     code_index + code_length - 1),
                        counts = TRUE))[[2]][1] == 1 &&
       attributes(adist(code, substr(sequence, code_index,
                                     code_index + code_length - 1),
                        counts = TRUE))[[2]][2] == 1) {
      trafo_seq <- attributes(adist(code, substr(sequence, code_index,
                                                 code_index + code_length - 1),
                                    counts = TRUE))$trafos
      index_miss <- gregexpr("D", trafo_seq)[[1]][1]
      index_insertion <- gregexpr("I", trafo_seq)[[1]][1]

      if(length(index_miss) == 1 && length(index_insertion) == 1) {
        if(index_miss < index_insertion)
          return(c(code_id, code_name, code, code_smiles,
                   "Missing Element / Insertion", index_miss, index_insertion,
                   code_index + code_length))
        else
          return(c(code_id, code_name, code, code_smiles,
                   "Insertion / Missing Element", index_insertion, index_miss,
                   code_index + code_length))
      }
      else
        return(paste("No allowed combination found"))
    }
    else {
      return(paste("No allowed combination found"))
    }
  }
  return(paste("No allowed combination found"))
}
