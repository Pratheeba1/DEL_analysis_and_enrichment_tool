

analyze_sequence_onesheet <- function(given_sequence,
                                      sheet_inf,
                                      thresholds_two_errors,
                                      error_threshold,
                                      onlymutation)
{
  seq_start <- get_sequence_start(given_sequence,sheet_inf)
  
  # seq_start <- sheet_inf$whole_prime_length + 1
  
  # Only Search for best Patterns and several Errors, if the Starting Point was
  # founded
  if(nchar(given_sequence) >= seq_start)
  {
    given_sequence <- substr(given_sequence,seq_start,nchar(given_sequence))
    comparison_result <- comparing_all_patterns_onesheet(given_sequence,
                                                         sheet_inf)
    lengths_parts <- sheet_inf$lengths_poss_codes
    ### Splitting up datasets for analyzing single code blocks
    
    ### Defining names and running through the remaining code blocks
    fused_data <- c()
    for(i in 1:(length(comparison_result[[1]]))){
      which_row <- which(sheet_inf$structure_sheet[, sheet_inf$sequence_cols[i]] ==  comparison_result[[1]][i])
      if(i%%2 == 0)
      {
        fused_data <- c(fused_data,as.character(c(sheet_inf$structure_sheet[which_row,paste0(sheet_inf$which_coloum_names[i],c("_ID","_name","_sequence"))],"No Smile")))
      }
      else
      {
        fused_data <- c(fused_data,as.character(sheet_inf$structure_sheet[which_row,paste0(sheet_inf$which_coloum_names[i],c("_ID","_name","_sequence","_smiles"))]))
      }
    }
    fused_data <- matrix(fused_data,ncol = 4,byrow = TRUE)
    
    
    #############################################################################
    ### Initiation of the algorithm for all given code blocks
    ### Algorithm runs through all possible error origins function by function
    code_index <- categorial_index <- 1
    sum_errors <<- 0
    result_vector <- c()
    bad_sequence <- FALSE
    repeat
    {
      if(!bad_sequence)
      {
        
        seq_parts <- comparison_result$seq_parts[c(categorial_index,categorial_index + 1)]-0:1
        # If the seq_part sequence is shorter than the best pattern for more than
        # errorthreshold, we can skip the errorsearch and say: Too many Errors
        result_at_index <- "Temp"
        
        length_diff <- lengths_parts[categorial_index] - (seq_parts[2]-seq_parts[1]+1)
        
        if(length_diff < error_threshold)
        {
          
          # Searching for mutation Errors only it only make sense, if the seq_part
          # sequence has the same length as the best pattern
          if(length_diff == 0)
          {
            result_at_index <-
              check_single_code(given_sequence,
                                fused_data[categorial_index, 1],
                                fused_data[categorial_index, 2],
                                fused_data[categorial_index, 3],
                                fused_data[categorial_index, 4],
                                code_index,
                                lengths_parts[categorial_index],
                                thresholds_two_errors,
                                seq_parts,
                                error_threshold)
            
          }
          
          if(!onlymutation)
          {
            ### Case: Previous search not successful => Search for missing element
            if(length(result_at_index) == 1 && length_diff > 0)
            {
              result_at_index <- check_single_code_for_miss_element(given_sequence,
                                                                    fused_data[categorial_index, 1],
                                                                    fused_data[categorial_index, 2],
                                                                    fused_data[categorial_index, 3],
                                                                    fused_data[categorial_index, 4],
                                                                    code_index,
                                                                    lengths_parts[categorial_index],
                                                                    seq_parts,
                                                                    error_threshold,
                                                                    length_diff)
              
              if(length(result_at_index) > 1)
              {
                sum_errors = sum_errors + as.numeric(result_at_index[9])
              }
            }
            ### Case: Previous search not successful => Search for insertion
            # Searching for insertion Errors only it only make sense, if the seq_part
            # sequence has the same length as the best pattern. Otherwise it has to
            # be a combined Error
            if(length(result_at_index) == 1 && length_diff == 0)
            {
              result_at_index <- check_single_code_for_insertion(given_sequence,
                                                                 fused_data[categorial_index, 1],
                                                                 fused_data[categorial_index, 2],
                                                                 fused_data[categorial_index, 3],
                                                                 fused_data[categorial_index, 4],
                                                                 code_index,
                                                                 lengths_parts[categorial_index],
                                                                 error_threshold,
                                                                 seq_parts
              )
              if(length(result_at_index) > 1)
              {
                sum_errors = sum_errors + 1
              }
            }
            ### Case: Previous search not successful => Search for combined errors
            if(length(result_at_index) == 1 && lengths_parts[categorial_index] >
               thresholds_two_errors)
            {
              result_at_index <-
                check_for_combined_errors(given_sequence,
                                          fused_data[categorial_index, 1],
                                          fused_data[categorial_index, 2],
                                          fused_data[categorial_index, 3],
                                          fused_data[categorial_index, 4],
                                          code_index,
                                          lengths_parts[categorial_index])
              #####
              if(length(result_at_index) > 1)
              {
                sum_errors = sum_errors + 2
              }
            }
          }
        }
      }
      ### Last option: Too many errors, returning placeholders and approximating
      ###              the error amount
      # if((length(result_at_index) == 1)|| bad_sequence)
      if((length(result_at_index) == 1))
      {
        result_at_index <-
          c("No ID", "No Name", "No Code", "No Smile",
            "Too many errors", "No Position", "No Position",
            code_index + lengths_parts[categorial_index] +
              attributes(adist(fused_data[categorial_index, 3],
                               substr(given_sequence,
                                      code_index, code_index +
                                        lengths_parts[categorial_index] - 1),
                               counts = TRUE))$counts[1] -
              attributes(adist(fused_data[categorial_index, 3],
                               substr(given_sequence,
                                      code_index, code_index +
                                        lengths_parts[categorial_index] - 1),
                               counts = TRUE))$counts[2]
          )
        sum_errors = sum_errors +
          as.numeric(adist(fused_data[categorial_index, 3],
                           substr(given_sequence, code_index, code_index +
                                    lengths_parts[categorial_index] - 1)))
        bad_sequence <- TRUE
      }
      ### Updating indices...
      result_vector <- c(result_vector, result_at_index)
      categorial_index <- categorial_index + 1
      code_index <- seq_parts[2] - 1
      if(categorial_index > nrow(fused_data)) break
    }
    
    
    ### Returning the vector of results for each codeblock and the sum of errors
    return(c(result_vector, sum_errors))
  }
  else
  {
    return(c(rep(c("NO ID Prime","NO Name Prime","No Code Prime","No Smile Prime","Too many errors Prime","No Position Prime", "No Position Prime",NA),length(sheet_inf$which_coloum_names)),NA))
    
  }
}



