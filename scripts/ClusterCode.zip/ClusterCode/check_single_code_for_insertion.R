### check_single_code_for_insertion - Searches for a single insertion within a
###                                   sequence part
###
### Input      - sequence    - character vector - to be analysed sequence
###              code_id     - ID of the code 
###              code_name   - name of the code
###              code        - string containing the nucleobases
###              code_smiles - optional SMILE for identification
###              code_index  - starting index within the sequence
###              code_length - length of the code in characters
### 
### Output     - Returning a vector with the following components:
###              code ID, code name, string with nucleobases, optional SMILE,
###              error report "Insertion", error position 1,
###              error position 2, running index after leaving the codeblock
###              OR
###              return of the character
###              "No Insertion found" if there are too many or other types
###              of errors found
# 
# sequence=given_sequence
# code_id=                fused_data[categorial_index, 1]
# code_name=          fused_data[categorial_index, 2]
# code=              fused_data[categorial_index, 3]
# code_smiles=                fused_data[categorial_index, 4]
# code_index=               code_index
# code_length=         lengths_parts[categorial_index]
# threshold_two_mutations=            thresholds_two_errors[categorial_index]
# seq_parts=comparison_result$seq_parts[c(categorial_index,categorial_index + 1)]-0:1

check_single_code_for_insertion <- function(sequence, 
                                            code_id, 
                                            code_name,
                                            code,
                                            code_smiles,
                                            code_index,
                                            code_length,
                                            error_threshold,
                                            seq_parts) 
{
  ### Construction of an enlarged sequence and the possible combinations of
  ### characters with one additional element
  extended_sequence <- strsplit(substr(sequence, code_index, 
                                       code_index + code_length),
                                split = "")[[1]]
  best_pattern     <- strsplit(code, split = "")[[1]]
  
  ### Case at the end of the sequence: remainder of the sequence shorter than
  ### the intermediate part with the expected length
  if(length(extended_sequence) -  length(best_pattern) < 1)
  {
    best_pattern <- best_pattern[1:(length(extended_sequence) - 1)]
  }
  extended_versions_of_the_code <- c("X", best_pattern)
  
  for(i in 1:code_length)
  {
    extended_versions_of_the_code <- 
      rbind(extended_versions_of_the_code, append(best_pattern, "X",
                                                  after = i))
  }
  
  amount_extended_versions <- dim(extended_versions_of_the_code)[1]
  
  
  ### Comparison of the constructed code with the given sequence part
  checking_index = 1
  repeat 
  {
    if(length(which(extended_sequence != 
                    extended_versions_of_the_code[checking_index,])) < 2) 
    {
      return(c(code_id, code_name, code, code_smiles,             ##Macht hier vlt eine Untersuchung von mehr als einer Insertion Sinn?
               "Insertion", checking_index - 1, checking_index,
               rep("No Position", error_threshold - 2),
               code_index + code_length + 1))
    } 
    checking_index = checking_index + 1
    if(checking_index == amount_extended_versions + 1) 
    {
      break
    }
  }
  paste("No Insertion found")
}