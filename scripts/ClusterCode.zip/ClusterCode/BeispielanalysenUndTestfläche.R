
library("xtable")
setwd("F:/TU Dortmund/Masterarbeit")
library("RobustLinearReg")
library("ggplot2")
source("GenerateData.R")
source("Helpfunctions.R")
source("SeasonalExponentialSmoothing.R")
source("SimpleExponentialSmoothing.R")
source("SimpleExponentialSmoothingTrend.R")
source("PlotMethod.R")
source("Datensimulierung.R")
# 0.4163172 0.4795502 0.1734210 0.6766812 0.9148772
initial_p <- 3
s <- 8
p <- 8
data_per_season <- 4
m <- s * initial_p * data_per_season
n <- p * s * data_per_season
# data_array1 <- create_data_array(size_x = size_x,
#                                  size_y = size_y,
#                                  p = p,
#                                  s = s,
#                                  m = m,
#                                  miss_rate = 0.2,
#                                  e = 0,period_length = 365)

data_array <- sim_data_arr(magn = 0,
                            sd = 0.04,
                            reg.time = 30,
                            bp = 50,
                            eps = 0.05,
                            s = s,
                            p = p,
                            m = m,
                            miss_rate = 0,
                            size_x = 10,
                            size_y = 10,
                            a = 1.6,
                            mu = -0.8,
                           data_per_season = data_per_season)

# plot(data_array$time,data_array$data[3,3,])

p_x = 4
p_y = 6
x <- c(0.6106069,0.1993866,0.3772297,0.98,0.7170231)
# x <- c(0.6106069,0.8,0.3772297,0.98,0.7170231)
# x <- p$par

lambdas <- c(0.4163172, 0.4795502, 0.1734210, 0.6766812, 0.9148772)
# 0.4163172 0.4795502 0.1734210 0.6766812 0.9148772
# Value 0.01319966



exp_smooth_season_data <- exp_smooth_season_arr(data_array = data_array,
                                               lambdas = lambdas,
                                                initial_p = 3,
                                                seasonStationarity = FALSE)

plot_timeline(exp_smooth_season_data,p_x = 3,p_y = 3)





# plot(exp_smooth_season_data$time,exp_smooth_season_data$smooth_data[9,5,])
############################################################################
pos_par <- seq(0.1,0.9,0.1)
comb_par <- expand.grid(pos_par,pos_par,pos_par,pos_par,pos_par,pos_par)
set.seed(42)


# Fehler in Iterartion:
# 62.0000000  


############################################################################
tune_params <- function(iter,
                        data_array,
                        period_length = 365,
                        initial_p = 3,
                        k = 2,
                        observe_dist = 3,
                        d_meth = "euclidean",
                        weight_fun = median,
                        seasonStationarity = FALSE)
{
  m <- initial_p * data_array$s
  n <- data_array$p * data_array$s
  
  pos_par <- seq(0.1,0.9,0.1)
  comb_par <- expand.grid(pos_par,pos_par,pos_par,pos_par,pos_par)
  start_values <- comb_par[sample(1:nrow(comb_par),iter),]
  par <- matrix(ncol = 5,nrow = iter)
  colnames(par) <- c("Var1","Var2","Var3","Var4","Var5")
  params <- list(par,numeric(iter))
  names(params) <- c("par","val")
  
  for(i in 1:iter)
  {
    print(i)
    tune_one_param <- function(x)
    {
      exp_smooth_season_data <- exp_smooth_season_arr(data_array = data_array,
                                                      lambda_location = x[1],
                                                      lambda_trend = x[2],
                                                      lambda_season = x[3], 
                                                      lambda_sigma = x[4],
                                                      lambda_m = x[5],
                                                      initial_p = initial_p,
                                                      seasonStationarity = TRUE)
      dx <- dim(exp_smooth_season_data$data)[1]
      dy <- dim(exp_smooth_season_data$data)[2]
      mse <- matrix(ncol = dy,nrow = dx )
      for(p_x in 1: dx)
      {
        if(p_x == dx){cat(p_x,"/",dx,"\n")}
        for(p_y in 1 : dy)
        {
          y <- exp_smooth_season_data$data[p_x,p_y,(m + 1) : n]
          y_hat <- exp_smooth_season_data$smooth_data[p_x,p_y,][-1]
          not_empty <- !is.na(y)
          mse[p_x,p_y] <- mean((y[not_empty] - y_hat[not_empty])^2)
        }
      }
      return(mean(mse))
    }
    p <- optim(as.numeric(start_values[i,]), tune_one_param,lower = 0.05,upper = 0.95,
               method = "L-BFGS-B",control = list(maxit = 5))
    params$par[i,] <- p$par
    params$val[i] <- p$value
  }
  return(params)
}

p <- tune_params(1,data_array)
save(p,file = "param2.RData")
save(p,file = "param2.rds")

x <- p$par[which.min(p$val),]

comb_par
str(comb_par)

par_val <- cbind(0,comb_par) 
colnames(par_val) <- c("Fit","lambda_location","lambda_trend","lambda_season","lambda_error","lambda_sigma","lambda_m")

nr <- nrow(comb_par)
for(i in 10001:nr)
{
  if(i%%1000 == 0){cat(i,"/",nr,"\n")}
  if(i%%10000 == 0)
  {
    cat(i,"/",nr,"\n")
    saveRDS(par_val[1:i,],file = paste0("param_",i,".rds"))
  }
  param <- parameter_check(data_array = data_array,
                           p_x = 3,
                           p_y = 3,
                           lambda_location = par_val$lambda_location[i],
                           lambda_trend = par_val$lambda_trend[i],
                           lambda_season = par_val$lambda_season[i], 
                           lambda_error = par_val$lambda_error[i], 
                           lambda_sigma = par_val$lambda_sigma[i],
                           lambda_m = par_val$lambda_m[i],
                           p = p,
                           s = s,
                           initial_p = 3)
  par_val$Fit[i] <-  sum(sapply(1:length(param),test2))
}
par_val[1:100,]

20000%%10000
x <- 1:10
save(x,file = "param.RData")
temp <- readRDS("param_90000.rds")

temp[which.min(temp$Fit[1:9999]),]
############################################################################
### Siehe  Robust control charts for time series data (Croux,Gelper,Mahieu)
error <- exp_smooth_season_data$residuen
c_k <- 1.404
k <- 2
s_0 <- median(abs(error))
test <- function(x)
{
  min(2^2,(error[x]/S_T)^2)
}

tau <- sqrt(c_k * s_0^2/(n - m) * sum(sapply(1:length(error),test)))

UCL <- z * tau
LCL <- -z * tau
plot(error)
abline(h = c(UCL,LCL))
############################################################################



fr <- function(x) {   ## Rosenbrock Banana function
  x1 <- x[1]
  x2 <- x[2]
  100 * (x2 - x1 * x1)^2 + (1 - x1)^2
}

optim(c(-1.2,1), fr,method = "BFGS")

################################################################################
################################################################################
################################################################################


as.integer(strsplit(as.character(ISOdate(2021,11,3)),"-")[[1]][1])


time <- ISOdate(1000:1050,11,3)
# Aus Vektor mit Zeiteintr�gen alle zugeh�rigen Jahreszahlen herausfiltern
year <- as.integer(unlist(strsplit(as.character(time),"-"))[seq(1,length(time) * 3,3)])

# Aus Vektor mit Zeiteintr�gen alle Monate herausfiltern:
month <- as.integer(unlist(strsplit(as.character(time),"-"))[seq(2,length(time) * 3,3)])

season <- function(x)
{
  if(x %in% 3:5)
  {
    return(1)
  }
  else if(x %in% 6:8)
  {
    return(2)
  }
  else if(x %in% 9:11)
  {
    return(3)
  }
  else if(x %in% 6:8)
  {
    return(4)
  }
  else
  {
    stop("No Valid Time Point")
  }
  
}
# Weise den Monaten eine Saison zu
sapply(month,season)

################################################################################
################################################################################
################################################################################
library("plot.matrix")
library("ggplot2")
m <- 121
d <- function(x)
{
  sqrt(sum((x - c((m + 1)/2,(m + 1)/2))^2))
  
}


temp <- cbind(rep(1:m,each = m),rep(1:m,m))
M <- matrix(round(apply(temp,1, d)),byrow = TRUE,nrow = m)
plot(M)
ggplot(M)
