### analyze_dataset - Wrapper for the previous function to process a whole
# ###                   dataset of sequences
# get_sequence_start <- source("get_sequence_start.R")$value
# check_single_code <- source("check_single_code.R")$value
# check_single_code_for_insertion <- source("check_single_code_for_insertion.R")$value
# check_single_code_for_miss_element <- source("check_single_code_for_miss_element.R")$value
# check_for_combined_errors <- source("check_for_combined_errors.R")$value
# comparing_all_patterns_onesheet <- source("comparing_all_patterns_onesheet.R")$value
# analyze_sequence_onesheet <- source("analyze_sequence_onesheet.R")$value
# get_indices_dataset <- source("get_indices_dataset.R")$value
# sheet_info <- source("sheet_info.R")$value



analyze_dataset <- function(sequences_dataset, 
                            sheet_inf,
                            thresholds_two_errors,
                            error_threshold,
                            onlymutation = TRUE) 
{
  ### Applying the procedure implemented in the previous function onto the
  ### vector sequences_dataset
  result_dataset <- 
    t(sapply(seq(1, length(sequences_dataset)), 
             function(x) 
               analyze_sequence_onesheet(given_sequence = as.character(sequences_dataset[x]), 
                                         sheet_inf = sheet_inf,
                                         thresholds_two_errors = thresholds_two_errors,
                                         error_threshold = error_threshold,
                                         onlymutation)
    ))

  # system.time(
  # 
  #   for(x in 1:1000)
  #   {
  #     v <- analyze_sequence_onesheet(given_sequence = as.character(sequences_dataset[x]),
  #                                    sheet_inf = sheet_inf,
  #                                    thresholds_two_errors = thresholds_two_errors,
  #                                    error_threshold = error_threshold,
  #                                    onlymutation = TRUE)
  # 
  #   }
  # 
  # 
  # )
  result_dataset <- cbind(as.data.frame(t(c(sheet_inf$which_sheet,sheet_inf$protein_info))),
                          result_dataset)
  
  ###
  ### Correction and adding labels
  result_dataset <- data.frame(result_dataset, stringsAsFactors = FALSE)
  result_dataset[,dim(result_dataset)[2]] <- 
    as.numeric(as.character(result_dataset[,dim(result_dataset)[2]]))
  ### The current vector of labels is based on the code blocks for the CEGAT
  ### dataset of 2021, please edit for other purposes
  
  colnames(result_dataset) <- c("MVDEL_1", 
                                "ProteinCode1_ID", "ProteinCode1_name", 
                                
                                "Region1Code_ID", "Region1Code_name", "Region1Code_code",
                                "Region1Code_smile", "Region1Code_Errors", 
                                "Region1Code_ErrorPosition1", "Region1Code_ErrorPosition2",  
                                "Region1Code_SplittingIndices",
                                
                                "Zwischenteil2_ID", "Zwischenteil2_name", "Zwischenteil2_code",
                                "Zwischenteil2_smile", "Zwischenteil2_Errors", 
                                "Zwischenteil2_ErrorPosition1","Zwischenteil2_ErrorPosition2", 
                                "Zwischenteil1_SplittingIndices",
                                
                                "Region2Code_ID", "Region2Code_name", "Region2Code_code",
                                "Region2Code_smile", "Region2Code_Errors", 
                                "Region2Code_ErrorPosition1","Region2Code_ErrorPosition2", 
                                "Region2Code_SplittingIndices",
                                
                                "Zwischenteil3_ID", "Zwischenteil3_name", "Zwischenteil3_code",
                                "Zwischenteil3_smile","Zwischenteil3_Errors",
                                "Zwischenteil3_ErrorPosition1","Zwischenteil3_ErrorPosition2", 
                                "Zwischenteil3_SplittingIndices",
                                
                                "Region3Code_ID", "Region3Code_name", "Region3Code_code",
                                "Region3Code_smile","Region3Code_Errors", 
                                "Region3Code_ErrorPosition1","Region3Code_ErrorPosition2", 
                                "Region3Code_SplittingIndices",
                                
                                
                                "SumOfErrors")
  # colnames(result_dataset) <- read.csv("ResultColnames.csv",sep = ";")[,2]
  return(result_dataset)
}




