comparing_all_patterns_onesheet <- function(given_sequence,
                                            sheet_inf)
{
  length_codes_minimal_error <- best_sequences <- 0
  index_in_sequence <- 1
  seq_parts <- numeric(sheet_inf$amount_code_blocks-3)
  seq_parts[1] <- 1
  interested_codeblocks <- 3:(sheet_inf$amount_code_blocks-2)
  ### Running through all code blocks...

  for(i in interested_codeblocks)
  {
    lengths_poss_code <- sheet_inf$lengths_poss_codes[i - 1]
    corresponding_seq_part <- substr(given_sequence, index_in_sequence,
                                     index_in_sequence + lengths_poss_code - 1)


    codes <- sapply(index_in_sequence - 1 + (1:sheet_inf$lengths_poss_codes[i - 2]), function(x) substr(given_sequence,index_in_sequence,x))

    compare_codes <- sheet_inf$code_blocks[i][[1]]
    # best_dist <- 1000
    # for(k in 1:length(compare_codes)){
    #   dist <- adist(compare_codes[k],codes) ################################################ Das ist die problematische Zeile
    #   # dist <- 2
    #   if(min(dist) < best_dist)
    #   {
    #     which_code <- which.min(dist)
    #     best_dist <- dist[which_code]
    #     best_sequence <- compare_codes[k]
    #   }
    # }
    which_code <- which.min(adist(compare_codes,codes[length(codes)]))[1]
    best_sequence <- compare_codes[which_code]
    which_code <- nchar(best_sequence)
    
    seq_parts[i - 1] <- seq_parts[i - 2] + which_code
    index_in_sequence <- index_in_sequence + which_code
    best_sequences[i - 2] <- best_sequence
  }
  results <- list(best_sequences,seq_parts)
  names(results) <- c("best_sequences","seq_parts")
  return(results)
}






# library(stringdist)

#calculate Levenshtein distance between two strings
# stringdist(compare_codes[k], codes, method = "lv")





# comparing_all_patterns_onesheet <- function(given_sequence,
#                                             sheet_inf,
#                                             start_point)
# {
#   length_codes_minimal_error <- best_sequences <- 0
#   index_in_sequence <- 1
#   seq_parts <- numeric(sheet_inf$amount_code_blocks-3)
#   seq_parts[1] <- 1
#   interested_codeblocks <- 3:(sheet_inf$amount_code_blocks-2)
#   ### Running through all code blocks...
#   
#   for(i in interested_codeblocks)
#   {
#     lengths_poss_code <- sheet_inf$lengths_poss_codes[i-1]
#     corresponding_seq_part <- substr(given_sequence, index_in_sequence,
#                                      index_in_sequence + lengths_poss_code-1)
#     
#     
#     codes <- sapply(index_in_sequence -1 + (1:sheet_inf$lengths_poss_codes[i-2]),function(x) substr(given_sequence,index_in_sequence,x))
#     compare_codes <- sheet_inf$code_blocks[i][[1]]
#     best_dist <- 1000
#     for(k in 1:length(compare_codes)){
#       dist <- adist(compare_codes[k],codes)
#       if(min(dist) < best_dist)
#       {
#         which_code <- which.min(dist)
#         best_dist <- dist[which_code]
#         best_sequence <- compare_codes[k]
#       }
#     }
#     seq_parts[i-1] <- seq_parts[i-2] + which_code
#     index_in_sequence <- index_in_sequence + which_code
#     best_sequences[i-2] <- best_sequence
#   }
#   results <- list(sheet_inf$which_sheet, best_sequences,
#                   sheet_inf$lengths_poss_codes,seq_parts)
#   names(results) <- c("which_sheet","best_sequences",
#                       "lengths_opt_codes","seq_parts")
#   return(results)
#   
#   
#   
# }