x <- c("MVDEL_1", 
       "ProteinCode_ID", "ProteinCode_name", 
      
       
       "Region1Code_ID", "Region1Code_name", "Region1Code_code",
       "Region1Code_smile", "Region1Code_Errors", 
       "Region1Code_ErrorPosition1", "Region1Code_ErrorPosition2",  
       "Region1Code_SplittingIndices",
       
       "Zwischenteil2_ID", "Zwischenteil2_name", "Zwischenteil2_code",
       "Zwischenteil2_smile", "Zwischenteil2_Errors", 
       "Zwischenteil2_ErrorPosition1","Zwischenteil2_ErrorPosition2", 
       "Zwischenteil1_SplittingIndices",
       
       "Region2Code_ID", "Region2Code_name", "Region2Code_code",
       "Region2Code_smile", "Region2Code_Errors", 
       "Region2Code_ErrorPosition1","Region2Code_ErrorPosition2", 
       "Region2Code_SplittingIndices",
       
       "Zwischenteil3_ID", "Zwischenteil3_name", "Zwischenteil3_code",
       "Zwischenteil3_smile","Zwischenteil3_Errors",
       "Zwischenteil3_ErrorPosition1","Zwischenteil3_ErrorPosition2", 
       "Zwischenteil3_SplittingIndices",
       
       "Region3Code_ID", "Region3Code_name", "Region3Code_code",
       "Region3Code_smile","Region3Code_Errors", 
       "Region3Code_ErrorPosition1","Region3Code_ErrorPosition2", 
       "Region3Code_SplittingIndices",
       
       
       "SumOfErrors")
write.csv2(x,file = "ResultColnames.csv")
length(x)
