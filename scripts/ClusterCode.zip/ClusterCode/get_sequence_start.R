### get_sequence_start - Finds the starting index of the sequence according
###                      to the first intermediate part
###
### Input              - sequence - sread-part of the sequence
###                      sheet   - Structure Sheet
###
### Output             - Starting index as an output of the gregexpr function
# 
get_sequence_start <- function(given_sequence,sheet_inf)
{
  if(nchar(given_sequence) < sheet_inf$whole_prime_length)
      {
        return(-1)
      }
  given <- strsplit(given_sequence,"")[[1]][1:sheet_inf$whole_prime_length]

  possible_starts <- which(given == sheet_inf$prime_sequence[1])
  possible_starts <- possible_starts[possible_starts <= sheet_inf$whole_prime_length-sheet_inf$prime_length + 1]
  possible_starts <- possible_starts[length(possible_starts):1]

  if(!is.na(possible_starts[1]))
  {
    for(i in possible_starts)
    {
      if(identical(given[i:(i+sheet_inf$prime_length-1)] ,sheet_inf$prime_sequence ))
      {
        return(i + sheet_inf$prime_length)
      }
    }
  }
  return(-1)
}


# From the End
# get_sequence_start <- function(given_sequence,sheet_inf) 
# {
#   if(nchar(given_sequence) < sheet_inf$whole_prime_length)
#   {
#     return(-1)
#   }
#   given <- strsplit(given_sequence,"")[[1]][(nchar(given_sequence) - sheet_inf$whole_prime_length + 1):nchar(given_sequence)]
#   
#   possible_starts <- which(given == sheet_inf$prime_sequence[1])
#   possible_starts <- possible_starts[possible_starts <= sheet_inf$whole_prime_length-sheet_inf$prime_length + 1]
#   possible_starts <- possible_starts[length(possible_starts):1]
#   
#   if(!is.na(possible_starts[1]))
#   {
#     for(i in possible_starts)
#     {
#       if(identical(given[i:(i+sheet_inf$prime_length-1)] ,sheet_inf$prime_sequence ))
#       {
#         return(i + sheet_inf$prime_length)
#       }
#     }
#   }
#   return(-1)
# }


