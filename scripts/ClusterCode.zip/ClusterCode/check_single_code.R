### check_single_code - Searches for a single or two mutations within a
###                     sequence part
###
### Input      - sequence    - character vector - to be analysed sequence
###              code_id     - ID of the code 
###              code_name   - name of the code
###              code        - string containing the nucleobases
###              code_smiles - optional SMILE for identification
###              code_index  - starting index within the sequence
###              code_length - length of the code in characters
###              threshold_two_mutations - threshold for allowing two mutations
###
### Output     - Returning a vector with the following components:
###              code ID, code name, string with nucleobases, optional SMILE,
###              error reporting string, error position 1,
###              error position 2, running index after leaving the codeblock
###              OR
###              return of the character
###              "Search for Insertion or missing elements" if there are too
###              many or other types of errors found

# 
# sequence=given_sequence
# code_id=                fused_data[categorial_index, 1]
# code_name=          fused_data[categorial_index, 2]
# code=              fused_data[categorial_index, 3]
# code_smiles=                fused_data[categorial_index, 4]
# code_index=               code_index
# code_length=         lengths_parts[categorial_index]
# threshold_two_mutations=            thresholds_two_errors[categorial_index]
# seq_parts=comparison_result$seq_parts[c(categorial_index,categorial_index + 1)]-0:1

check_single_code <- function(sequence, 
                              code_id, 
                              code_name,
                              code, 
                              code_smiles,
                              code_index, 
                              code_length,
                              threshold_two_mutations,
                              seq_parts,
                              error_threshold) 
{
  
  ### Construction of vectors for comparison
  sequence_part_splitted <- strsplit(substr(sequence,seq_parts[1],seq_parts[2]), split = "")[[1]]
  
  code_splitted  <- strsplit(code, split = "")[[1]]
  
  ### Case at the end of the sequence: remainder of the sequence shorter than
  ### the intermediate part with the expected length
  if(length(sequence_part_splitted) < length(code_splitted))
  {
    code_splitted <- code_splitted[1:length(sequence_part_splitted)]
  }
  ### Comparison vector and related amount of errors
  comparison_vec <- which(code_splitted != sequence_part_splitted)
  amount_errors  <- length(comparison_vec)
  
  ### Return depending on the amount of errors
  if(amount_errors <= error_threshold)
  {
    if(amount_errors == 0)
    {
      return(c(code_id, code_name, code, code_smiles, "No Error", 
               rep("No Position",error_threshold), code_index + code_length))
    }
    else if(amount_errors == 1)
    {
      sum_errors <<- sum_errors + amount_errors
      return(c(code_id, code_name, code, code_smiles, "1 Mutation",
               comparison_vec, rep("No Position",error_threshold - amount_errors), code_index + code_length))
    }
    else 
    {
      sum_errors <<- sum_errors + amount_errors
      return(c(code_id, code_name, code, code_smiles, paste(amount_errors,"Mutations"),
               comparison_vec, rep("No Position",error_threshold - amount_errors), code_index + code_length))
    }
  }
  else
  {
    paste("Search for Insertion or missing elements")
  }
}
