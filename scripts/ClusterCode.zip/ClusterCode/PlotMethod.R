## plot_timeline
## Input : plotdata = Dataframe:
##                      - 1. Spalte : Gruppe
##                      - 2. Spalte : Zeitpunkt
##                      - 3. Spalte : Datenwert
## Output : Grafische Visualisierung mit Differenzierung zwischen den einzelnen
##          Gruppen

# plot_timeline <- function(plotdata,
#                           palette = c("#000000", "#E69F00","#56B4E9", "#009E73", 
#                                       "#F0E442", "#0072B2", "#D55E00", "#CC79A7"))
# {
#   ggplot(plotdata,aes(time,y,group = Group)) + 
#     geom_point(aes(color = Group,shape = Group)) +
#     geom_line(aes(color = Group,linetype = Group)) +
#     scale_color_manual(values = palette) +
#     scale_linetype_manual(values=c("solid", "solid","solid")) +
#     theme(legend.position = "right",
#           panel.grid.major = element_line(size = 0.5, 
#                                           linetype = 'solid',
#                                           colour = "#888888"),
#           panel.grid.minor = element_line(size = 0.25, 
#                                           linetype = 'solid', #Oder longdash,solid,dotted?
#                                           colour = "#aaaaaa"),
#           panel.background = element_rect(fill = "white", colour = "white",size = 0.5, linetype = "solid"),
#           panel.border = element_rect(fill = NA)) +
#     scale_y_continuous(name = "y",breaks = seq(floor(min(plotdata$y,na.rm = TRUE)),
#                                                ceiling(max(plotdata$y,na.rm = TRUE)),1)) +
#     scale_x_continuous(name = "Time",breaks = seq(floor(min(plotdata$time)),ceiling(max(plotdata$time)),5)) +
#     geom_vline(xintercept = plotdata$time[m],colour = "#800000",size = 1) +
#     geom_text(aes(time[m],1,label = "Smooth Start")) +
#     ggtitle("Spannender Titel") 
# }




## plot_matrix
## Input : data_matrix = beliebige Matrix mit Doublewerten
## Output : Grafische Darstellung der Matrix mit farblicher Gr��enabstufung
plot_matrix <- function(data_matrix)
{
  nc <- ncol(data_matrix)
  nr <- nrow(data_matrix)
  data <- as.data.frame(cbind(rep(1:nc,each = nr),rep(1:nr,nc),as.vector(data_matrix)))
  colnames(data) <- c("x","y","z")
  annotation <- data.frame(
    x = data$x,
    y = data$y + 0.35,
    label = round(data$z,digits = 1)
  )
  
  ggplot(data,aes(x, y) ) +
    geom_point(aes(x,y,colour = z), data = data,size = 7,shape = 19) +
    geom_text(data = annotation, aes(x = x, y = y, label = label), color = "black",size = 3)+
    scale_y_continuous(name = "y",breaks = seq(floor(min(data$y,na.rm = TRUE)),
                                               ceiling(max(data$y,na.rm = TRUE)),2)) +
    scale_x_continuous(name = "x",breaks = seq(floor(min(data$x)),ceiling(max(data$x)),2)) 
}

################################################################################
################################################################################
################################################################################

plot_timeline <- function(data_array,
                          p_x,
                          p_y,
                          palette = c("#000000", "#E69F00","#56B4E9", "#009E73", 
                                      "#F0E442", "#0072B2", "#D55E00", "#CC79A7"))
{
  smooth_data <- data.frame("exp_smooth_season",data_array$time,data_array$smooth_data[p_x,p_y,])
  colnames(smooth_data) <- c("Group","time","y")
  
  plotdata <- data.frame("Data",data_array$fulltime,data_array$data[p_x,p_y,] ) 
  colnames(plotdata) <- c("Group","time","y")
  plotdata <- rbind(plotdata,smooth_data)

  
  # m <- data_array$m
  
  ggplot(plotdata,aes(time,y,group = Group)) + 
    geom_point(aes(color = Group,shape = Group)) +
    geom_line(aes(color = Group,linetype = Group)) +
    scale_color_manual(values = palette) +
    scale_linetype_manual(values=c("solid", "solid","solid")) +
    theme(legend.position = "right",
          panel.grid.major = element_line(size = 0.5, 
                                          linetype = 'solid',
                                          colour = "#888888"),
          panel.grid.minor = element_line(size = 0.25, 
                                          linetype = 'solid', #Oder longdash,solid,dotted?
                                          colour = "#aaaaaa"),
          panel.background = element_rect(fill = "white", colour = "white",size = 0.5, linetype = "solid"),
          panel.border = element_rect(fill = NA)) +
    scale_y_continuous(name = "y",breaks = seq(floor(min(plotdata$y,na.rm = TRUE)),
                                               ceiling(max(plotdata$y,na.rm = TRUE)),0.25)) +
    # scale_x_continuous(name = "Time",breaks = seq(floor(min(plotdata$time)),ceiling(max(plotdata$time)),100)) +
    scale_x_continuous(name = "Time",breaks = seq(0,ceiling(max(plotdata$time)),100)) +
    geom_vline(xintercept = plotdata$time[m],colour = "#800000",size = 1) +
    geom_text(aes(time[m],1,label = "Smooth Start")) +
    ggtitle("Spannender Titel") 
}


