# if (!require("BiocManager", quietly = TRUE))
#   install.packages("BiocManager")
# 
# BiocManager::install("Biostrings")
# BiocManager::install("ShortRead")


### Masterscript zum Durchlauf eines Datensatzes auf dem Computecluster
rm(list = ls())
# Was fehlt:
### Laden der Pakete
# library(readxl)
# library(ShortRead)#
library(Biostrings)##
# library(seqinr)
# library(magrittr)
# library(dplyr)
# library(gtools)
# library(stringr)
##########

install.packages("readxl")
install.packages("ShortRead")#############################
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("ShortRead")
install.packages("Biostrings")##
install.packages("seqinr")
install.packages("magrittr")
install.packages("dplyr")
install.packages("gtools")
# install.packages("stringr")
which_protein <- 1
# Pool 1 Data:

setwd("E:/TU Dortmund/DEL Auswertung/Enrichment-Analyse2020/Pool3_Complete/MVDEL_Data")
# data_fastq <- readFastq(paste0("S6275Nr",which_protein,".1.fastq.gz"))
l <- numeric(17)
for(i in 1:17)
{
  data_fastq <- readFastq(paste0("S6275Nr",i,".1.fastq.gz"))
  l[i] <- length(data_fastq)
}



setwd("G:/TU Dortmund/DEL Auswertung/Enrichment-Analyse2020/Pool1/Pool1_Data")
data_fastq <- readFastq(paste0("S2904Nr",which_protein,".1.fastq.gz"))
l <- numeric(19)
for(i in 1:19)
{
  data_fastq <- readFastq(paste0("S2904Nr",i,".1.fastq.gz"))
  l[i] <- length(data_fastq)
}
data_fastq1 <- data_fastq
# Pool 2 Data:

setwd("G:/TU Dortmund/DEL Auswertung/Enrichment-Analyse2020")
data_fastq <- readFastq(paste0("./MVDEL_Data/S3688Nr",which_protein,".1.fastq.gz"))

l <- numeric(29)
for(i in 1:29)
{
  data_fastq <- readFastq(paste0("./MVDEL_Data/S3688Nr",i,".1.fastq.gz"))
                          l[i] <- length(data_fastq)
}
data_fastq2 <- data_fastq

setwd("G:/TU Dortmund/DEL Auswertung/Enrichment-Analyse2020")
structure_sheet <- read_excel("CEGAT_MVDEL_Pool1_StructureSheet.xlsx")
structure_sheet <- read_excel("CEGAT_MVDEL_Pool2_StructureSheet.xlsx")
# Pool 2


data_fastq <- data_fastq1
data_fastq <- data_fastq2

setwd(paste0(getwd(),"/Schuessler_analyze"))
source("analyze_datasets.R")

sheet_inf <- sheet_info("MVDEL_1",structure_sheet,which_protein,prime_length = 8)
matching_indices <- get_indices_dataset(length(data_fastq),step = 10000)
seq_data <- data_fastq

t <- 1
sequences_dataset <- data_fastq@sread[matching_indices[t, 1]:matching_indices[t, 2]]
################################################################################
################################################################################
################################################################################
paste_vector <- function(x)
{
  res <- c()
  for(i in 1:length(x))
  {
    res <- paste0(res,x[i])
  }
  return(res)
}

primes <- function(sequences,sheet_inf)
{
  res <- character(length(sequences))
  for (i in 1:length(sequences)) 
  {
    res[i] <- paste_vector(strsplit(sequences[i],"")[[1]][1:sheet_inf$whole_prime_length])
  }
  return(res)
}

seq_start_analyze <- function(sequences_dataset,position = 30,pos1 = 1,pos2 = 29)
{
  n <- length(sequences_dataset)
  start_point <- numeric(n)
  sequences_dataset <- as.character(sequences_dataset)
  for(i in 1:n)
  {
    start_point[i] <- get_sequence_start(sequences_dataset[i],sheet_inf)
  }
  sequences_dataset_error <- sequences_dataset[start_point == -1]
  sequences_dataset_top <- sequences_dataset[start_point != -1]
  
  # Finde First_Part
  
  first_part_length <- sheet_inf$whole_prime_length - sheet_inf$prime_length
  prime_length <- sheet_inf$whole_prime_length 
  whole_prime_sequence <- sheet_inf$code_blocks$Zwischenteil1_sequence
  first_part <- strsplit(whole_prime_sequence,"")[[1]][1:first_part_length]
  ###
  prime_in_sequence <- primes(sequences_dataset,sheet_inf)
  find_first_part <- logical(n)
  for(i in 1:n)
  {
    text <- strsplit(prime_in_sequence[i],"")[[1]]
    if(length(text) >= first_part_length)
    {
      text <- text[1:first_part_length]
    }
    find_first_part[i]<- identical(prime,text)
  }
  find_first_part <- as.data.frame(table(find_first_part)/n*100)
  colnames(find_first_part) <- c("found","Freq")
  ##############################################################################
  find_cut_prime <- logical(n)
  for(i in 1:n)
  {
    text <- strsplit(prime_in_sequence[i],"")[[1]]
    if(length(text) >= prime_length)
    {
      text <- text[(prime_length - length(sheet_inf$prime_sequence) + 1) : prime_length]
    }
    find_cut_prime[i]<- identical(sheet_inf$prime_sequence,text)
  }
  find_cut_prime <- as.data.frame(table(find_cut_prime)/n*100)
  colnames(find_cut_prime) <- c("found","Freq")
  ##############################################################################
  specific_position <- numeric(n)
  for(i in 1:n)
  {
    specific_position[i] <- strsplit(sequences_dataset[i],"")[[1]][position]
  }
  specific_position[is.na(specific_position)] <- "Missing"
  specific_position <- as.data.frame(table(specific_position))
  colnames(specific_position) <- c(paste0("Letter at Pos ",position),"Freq")
  ##############################################################################
  analyce_cut_intervall <- logical(n)
  for(i in 1:n)
  {
    sequence <- sequences_dataset[i]
    if(nchar(sequence) >= pos2)
    {
      analyce_cut_intervall[i] <- paste_vector(strsplit(sequence,"")[[1]][pos1:pos2])
    }
    else
    {
      analyce_cut_intervall[i] <- "Too Short"
    }
  }
  
  find_cut_prime
  find_first_part
  specific_position
  analyce_cut_intervall
}
cut_prime <- paste_vector(sheet_inf$prime_sequence)
unique_codes <- sort(unique(analyce_cut_intervall[analyce_cut_intervall != paste_vector(sheet_inf$prime_sequence)]))

unique_codes <- sort(analyce_cut_intervall[analyce_cut_intervall != paste_vector(sheet_inf$prime_sequence)])
table(adist(cut_prime,unique_codes))

unique_codes[which(adist(cut_prime,unique_codes) == 2)]
length(unique_codes)
(4143-365-251)/4143
# Pool 1

# found Freq
# 1 FALSE   45
# 2  TRUE   55

# > find_first_part
# found Freq
# 1 FALSE  6.1
# 2  TRUE 93.9

# >   specific_position
# Letter at Pos 30 Freq
# 1                A  244
# 2                C  291
# 3                G   76
# 4                T  389

# Pool 2

# found Freq
# 1 FALSE 41.2
# 2  TRUE 58.8

# >   find_first_part
# found Freq
# 1 FALSE 24.4
# 2  TRUE 75.6

# >   specific_position
# Letter at Pos 30 Freq
# 1          Missing   22
# 2                N  978

# res2 <- vector(mode = "list",length = length(sequences_dataset_error))






res <- sequences_dataset
for(i in 1:length((res)))
{
  
  text <- strsplit(res[i],"")[[1]]
  if(length(text) >= 37)
  {
    text <- text[31:37]
  }
  res[i]<- paste_vector(text)
  
}
# table(res == "AGTCCTCTN")
# temp <- logical(length(res))
# for(i in 1:length(res))
# {
#   text <- strsplit(res[i],"")[[1]]
#   temp[i] <- "n" %in% text
# }

################################################################################
################################################################################
################################################################################
result_dataset<- analyze_dataset(sequences_dataset = sequences_dataset,
                  sheet_inf = sheet_inf,
                  thresholds_two_errors = 20,
                  error_threshold = 2,
                  onlymutation = TRUE)
system.time(result_dataset<- analyze_dataset(sequences_dataset = sequences_dataset,
                                             sheet_inf = sheet_inf,
                                             thresholds_two_errors = 20,
                                             error_threshold = 2,
                                             onlymutation = TRUE))

# 52 min per 1 Million data.points with given Starting Point
# 112 min per 1 Million data.points with adist calculation

# "A" "G" "T" "C" "C" "T" "C" "T"
# ACACTTTA      ACCTACTT      ATACTATC      CAATTACA      CATTACTA      CCCTATTA      CTACATCT       No Code No Code Prime 
# 10            14            52            21            17            30            66           198           444 
# TACCTACT      TACTACCA      TATCATTT      TCACATAC      TCACATCT      TCATATCA      TTCCACTA 
# 32            31            40            11             1            19            14 

# "A" "G" "G" "T" "C" "G" "G" "T"
# ACACTTTA      ACCTACTT      ATACTATC      CAATTACA      CATTACTA      CCCTATTA      CTACATCT       No Code No Code Prime 
# 10            16            54            19            19            32            71           604            16 
# TACCTACT      TACTACCA      TATCATTT      TCACATAC      TCACATCT      TCATATCA      TTCCACTA 
# 34            30            42            13             6            19            15 




# x <- c(867205,763273,471162,1464421,932240,666426,742254,1004399,
#        1300744,714145,998703,592715,784737,1105382,528611,890169,
#        802667,688449,1145580)
# p <- ceiling(x/100000)


# sequences_dataset[37693]
# "GGGGGGGGGGGGGGGGGGGGGGGGGGAGGGGGGCAAGGGGGCGTGGGGGGACCGGAAGGGCAGGGGCGAGATGGGGCGGGTGACACATGGCCGAGCCGACG"
# Error in i:(i + sheet_inf$prime_length - 1) : NA/NaN argument

table(result_dataset$Region1Code_Errors)
table(result_dataset$Region2Code_Errors)
table(result_dataset$Region3Code_Errors)

################################################################################
table(result_dataset$Region1Code_ID)
table(result_dataset$Region2Code_ID)
table(result_dataset$Region3Code_ID)

n <- 100000
starts <- numeric(n)
for(i in 1:n)
{
  starts[i] <- get_sequence_start(as.character(sequences_dataset[i]),sheet_inf)
}
given_sequence <- as.character(sequences_dataset[1])

# "A" "G" "T" "C" "C" "T" "C" "T"
# starts
# -1   20   21   23   24   25   26   27   28   29   30 
# 4454    1    1    1    1    2    1    6    8   40 5485 

# [1] "A" "G" "G" "T" "C" "G" "G" "T"
# > table(starts)
# starts
# -1    9   10   19 
# 140 9851    8    1 

# Search from the End
# "G" "G" "T" "C" "T" "A" "C" "A"
# starts
# -1     9    10    11    12    13    14    15    16    17    18    19    20    21    22    23    24 
# 10690    43   508   468  7853   454    22    19    13    22    22    21     8     3    13    45 79796 

table(starts)
sheet_inf$prime_sequence

AGTCCTCT
