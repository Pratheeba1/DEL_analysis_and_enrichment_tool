get_indices_dataset <- function(x,step = 100000) 
{
  first_col = seq(1, x, step)
  sec_col   = seq(1, x, step) + step - 1
  length_sec_col = length(sec_col)
  cbind(first_col, c(sec_col[-length_sec_col], x))
}