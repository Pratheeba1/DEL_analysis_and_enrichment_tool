sheet_info <- function(which_sheet,structure_sheet,which_protein,prime_length = 8)
{
  sequences           <- structure_sheet %>% select(ends_with("_sequence"))
  amount_code_blocks  <- dim(sequences)[2]
  ### Saving the possible codes for each code block
  code_blocks         <- na.omit(sequences[,1])
  for(i in 2:amount_code_blocks)
  {
    code_blocks     <- c(code_blocks, na.omit(sequences[,i]))
  }
  
  lengths_poss_codes <- c()
  for(i in 2:(amount_code_blocks-2))
  {
    lengths_poss_codes <- c(lengths_poss_codes,nchar(code_blocks[[i]][1]))
  }
  
  protein_info <- c(structure_sheet$ProteinCode1_ID[which_protein],
                    structure_sheet$ProteinCode1_name[which_protein])
  
  which_coloum_names <- unique(sapply(1:ncol(structure_sheet),function(x) strsplit(colnames(structure_sheet),"_")[[x]][1]))
  which_coloum_names <- which_coloum_names[3:(length(which_coloum_names)-2)]
  
  which_regions <- which_coloum_names[2 * (1:((length(which_coloum_names))/2))]
  
  code_ZT1_sheet <- as.character(structure_sheet %>% select(ends_with("_sequence")) %>%
                                   select(starts_with("Zwischenteil1")) %>%
                                   filter(row_number()==1))
  whole_prime_length <- nchar(code_ZT1_sheet)
  prime_sequence <- strsplit(code_ZT1_sheet,"")[[1]][(nchar(code_ZT1_sheet)-prime_length + 1):nchar(code_ZT1_sheet)]
  
  # prime_sequence <- strsplit(code_ZT1_sheet,"")[[1]][1:prime_length]
# ################################################################################
#   code_ZT4_sheet <- as.character(structure_sheet %>% select(ends_with("_sequence")) %>%
#                                    select(starts_with("Zwischenteil4")) %>%
#                                    filter(row_number()==1))
#   whole_prime_length <- nchar(code_ZT4_sheet)
#   prime_sequence <- strsplit(code_ZT4_sheet,"")[[1]][(nchar(code_ZT4_sheet)-prime_length + 1):nchar(code_ZT4_sheet)]
#   
#   ################################################################################
  sequence_cols <- which(colnames(structure_sheet)%in%paste0(which_coloum_names,"_sequence") )
  
  sheet_inf <- list(which_sheet = which_sheet,
                    structure_sheet = structure_sheet,
                    amount_code_blocks = amount_code_blocks,
                    code_blocks = code_blocks,
                    lengths_poss_codes = lengths_poss_codes[-1],
                    protein_info = protein_info,
                    which_protein = which_protein,
                    which_coloum_names = which_coloum_names,
                    which_regions = which_regions,
                    prime_sequence = prime_sequence,
                    prime_length = length(prime_sequence),
                    whole_prime_length = whole_prime_length,
                    sequence_cols = sequence_cols)
  return(sheet_inf)
}

